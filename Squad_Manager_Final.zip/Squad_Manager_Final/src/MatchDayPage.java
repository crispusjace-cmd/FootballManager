import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

/** Schedule fixtures, record results and see how the season is going. */
public class MatchDayPage extends Page {

    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("EEE d MMM", Locale.ENGLISH);

    private final StatCard playedCard = new StatCard("Played", "match", Theme.BLUE);
    private final StatCard recordCard = new StatCard("W - D - L", "ball", Theme.GREEN);
    private final StatCard goalsCard = new StatCard("Goals for / against", "goal", Theme.GOLD);
    private final StatCard pointsCard = new StatCard("Points", "bolt", new Color(255, 112, 112));
    private final Theme.VList fixtures = new Theme.VList();
    private final Theme.VList results = new Theme.VList();

    public MatchDayPage(AppShell app) {
        super(app);
        Theme.Btn schedule = Theme.button("+  Schedule match", Theme.Kind.PRIMARY);
        schedule.addActionListener(e -> scheduleForm());
        add(header("Match Day", "Plan fixtures, record results and track your season.", schedule), BorderLayout.NORTH);

        JPanel stats = box(new GridLayout(1, 4, 16, 0));
        stats.add(playedCard);
        stats.add(recordCard);
        stats.add(goalsCard);
        stats.add(pointsCard);

        Theme.Card fx = new Theme.Card("Upcoming fixtures");
        JScrollPane s1 = Theme.scroll(fixtures);
        s1.setPreferredSize(new Dimension(300, 320));
        fx.body.add(s1, BorderLayout.CENTER);
        Theme.Card rs = new Theme.Card("Results");
        JScrollPane s2 = Theme.scroll(results);
        s2.setPreferredSize(new Dimension(300, 320));
        rs.body.add(s2, BorderLayout.CENTER);

        JPanel cols = box(new GridLayout(1, 2, 16, 0));
        cols.add(fx);
        cols.add(rs);

        JPanel center = box(new BorderLayout(0, 16));
        center.add(stats, BorderLayout.NORTH);
        center.add(cols, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);
    }

    @Override
    public void refresh() {
        int[] r = store.record();
        int played = r[0] + r[1] + r[2];
        playedCard.set(String.valueOf(played), store.upcoming().size() + " fixtures to go");
        recordCard.set(r[0] + " - " + r[1] + " - " + r[2], played == 0 ? "no results yet" : r[0] * 100 / played + "% win rate");
        goalsCard.set(r[3] + " / " + r[4], "goal difference " + (r[3] - r[4] >= 0 ? "+" : "") + (r[3] - r[4]));
        pointsCard.set(String.valueOf(r[0] * 3 + r[1]), "3 for a win, 1 for a draw");

        fixtures.removeAll();
        List<Match> up = store.upcoming();
        for (Match m : up) fixtures.addRow(fixtureRow(m));
        if (up.isEmpty()) fixtures.add(Theme.label("No fixtures yet. Click \"Schedule match\".", 13, Font.PLAIN, Theme.MUTED));

        results.removeAll();
        List<Match> res = store.results();
        for (Match m : res) results.addRow(resultRow(m));
        if (res.isEmpty()) results.add(Theme.label("Results will appear here after you record a match.", 13, Font.PLAIN, Theme.MUTED));
        revalidate();
        repaint();
    }

    // ------------------------------------------------------------ rows
    private JComponent dateBlock(LocalDate d, Color accent) {
        return new JComponent() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                Theme.aa(g2);
                g2.setColor(Theme.alpha(accent, 30));
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
                g2.setFont(Theme.font(Font.BOLD, 18));
                g2.setColor(Theme.TEXT);
                String day = String.valueOf(d.getDayOfMonth());
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(day, (getWidth() - fm.stringWidth(day)) / 2, 25);
                g2.setFont(Theme.font(Font.BOLD, 10.5f));
                g2.setColor(accent);
                String mon = d.getMonth().getDisplayName(java.time.format.TextStyle.SHORT, Locale.ENGLISH).toUpperCase();
                fm = g2.getFontMetrics();
                g2.drawString(mon, (getWidth() - fm.stringWidth(mon)) / 2, 42);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(52, 52); }
        };
    }

    private JComponent fixtureRow(Match m) {
        Theme.Rounded row = new Theme.Rounded(new BorderLayout(14, 0), Theme.CARD_ALT, null, 16);
        row.setBorder(new EmptyBorder(10, 12, 10, 12));
        row.add(dateBlock(m.getDate(), Theme.BLUE), BorderLayout.WEST);
        JPanel mid = box(new GridLayout(2, 1, 0, 2));
        mid.add(Theme.label("vs " + m.getOpponent(), 15, Font.BOLD, Theme.TEXT));
        mid.add(Theme.label(m.getDate().format(DAY) + "  ·  " + m.getVenue(), 12, Font.PLAIN, Theme.MUTED));
        row.add(mid, BorderLayout.CENTER);
        Theme.Btn rec = Theme.button("Record result", Theme.Kind.PRIMARY).compact();
        Theme.Btn del = Theme.button("Delete", Theme.Kind.GHOST).compact();
        rec.addActionListener(e -> resultForm(m));
        del.addActionListener(e -> deleteMatch(m));
        JPanel buttons = box(new FlowLayout(FlowLayout.RIGHT, 6, 9));
        buttons.add(del);
        buttons.add(rec);
        row.add(buttons, BorderLayout.EAST);
        return row;
    }

    private JComponent resultRow(Match m) {
        Theme.Rounded row = new Theme.Rounded(new BorderLayout(14, 0), Theme.CARD_ALT, null, 16);
        row.setBorder(new EmptyBorder(10, 12, 10, 12));
        String letter = m.getResultLetter();
        Color accent = letter.equals("W") ? Theme.GREEN : letter.equals("D") ? Theme.GOLD : Theme.RED;
        JPanel badge = box(new GridBagLayout());
        badge.add(DashboardPage.formChip(letter));
        row.add(badge, BorderLayout.WEST);
        JPanel mid = box(new GridLayout(2, 1, 0, 2));
        mid.add(Theme.label(m.getOpponent(), 15, Font.BOLD, Theme.TEXT));
        mid.add(Theme.label(m.getDate().format(DAY) + "  ·  " + m.getVenue() + scorerText(m), 12, Font.PLAIN, Theme.MUTED));
        row.add(mid, BorderLayout.CENTER);
        JLabel score = Theme.label(m.getGoalsFor() + " - " + m.getGoalsAgainst(), 22, Font.BOLD, accent);
        Theme.Btn del = Theme.button("Delete", Theme.Kind.GHOST).compact();
        del.addActionListener(e -> deleteMatch(m));
        JPanel right = box(new FlowLayout(FlowLayout.RIGHT, 10, 7));
        right.add(score);
        right.add(del);
        row.add(right, BorderLayout.EAST);
        return row;
    }

    private String scorerText(Match m) {
        if (m.getScorers().isEmpty()) return "";
        List<String> names = new ArrayList<>();
        for (int s : m.getScorers()) {
            Player p = store.players().searchPlayer(s);
            if (p != null) names.add(p.getShortName());
        }
        return names.isEmpty() ? "" : "  ·  " + String.join(", ", names);
    }

    // ------------------------------------------------------------ dialogs
    private void scheduleForm() {
        Theme.Field opponent = new Theme.Field("", "e.g. Kampala City FC");
        Theme.Field date = new Theme.Field(LocalDate.now().plusDays(7).toString(), "YYYY-MM-DD");
        Theme.Combo venue = new Theme.Combo("Home", "Away");
        boolean ok = FormDialog.show(this, "Schedule match", "Add an upcoming fixture to your calendar.", "Schedule",
                new String[]{"Opponent", "~Date (YYYY-MM-DD)", "~Venue"},
                new JComponent[]{opponent, date, venue},
                () -> {
                    if (opponent.getText().trim().isEmpty()) return "Please enter the opponent's name.";
                    try { LocalDate.parse(date.getText().trim()); }
                    catch (Exception ex) { return "Date must look like 2026-12-05 (year-month-day)."; }
                    return null;
                });
        if (ok) {
            store.matches().add(new Match(opponent.getText().trim(), LocalDate.parse(date.getText().trim()),
                    (String) venue.getSelectedItem()));
            app.changed();
            app.toast("Match scheduled vs " + opponent.getText().trim());
        }
    }

    private void resultForm(Match m) {
        Theme.Field gf = new Theme.Field("0");
        Theme.Field ga = new Theme.Field("0");
        boolean ok = FormDialog.show(this, "Record result", "Final score for the match against " + m.getOpponent() + ".",
                "Continue", new String[]{"~" + store.getTeamName() + " goals", "~" + m.getOpponent() + " goals"},
                new JComponent[]{gf, ga},
                () -> {
                    Integer a = parseInt(gf.getText()), b = parseInt(ga.getText());
                    if (a == null || b == null || a < 0 || b < 0) return "Enter the goals as whole numbers (0 or more).";
                    if (a > 15 || b > 15) return "That score looks too high. Please check it.";
                    return null;
                });
        if (!ok) return;
        int goalsFor = parseInt(gf.getText()), goalsAgainst = parseInt(ga.getText());
        List<Integer> scorers = new ArrayList<>();
        if (goalsFor > 0 && store.players().getTotalPlayers() > 0) {
            List<Player> squad = store.players().getPlayers();
            squad.sort(Comparator.comparingInt(Player::getShirtNumber));
            String[] labels = new String[goalsFor];
            Theme.Combo[] combos = new Theme.Combo[goalsFor];
            String[] names = new String[squad.size() + 1];
            names[0] = "Unassigned / own goal";
            for (int i = 0; i < squad.size(); i++) names[i + 1] = "#" + squad.get(i).getShirtNumber() + "  " + squad.get(i).getName();
            for (int i = 0; i < goalsFor; i++) {
                labels[i] = "Goal " + (i + 1) + " scored by";
                combos[i] = new Theme.Combo(names);
            }
            JComponent[] inputs = combos;
            if (goalsFor > 6) {   // keep the dialog a sensible size
                labels = Arrays.copyOf(labels, 6);
                inputs = Arrays.copyOf(combos, 6);
            }
            boolean picked = FormDialog.show(this, "Who scored?", "Pick the scorer for each goal so player stats stay up to date.",
                    "Save result", labels, inputs, () -> null);
            if (!picked) return;
            for (int i = 0; i < Math.min(goalsFor, 6); i++) {
                int idx = combos[i].getSelectedIndex();
                if (idx > 0) scorers.add(squad.get(idx - 1).getShirtNumber());
            }
        }
        store.recordResult(m, goalsFor, goalsAgainst, scorers);
        app.changed();
        app.toast("Result saved: " + goalsFor + " - " + goalsAgainst);
    }

    private void deleteMatch(Match m) {
        String msg = m.isPlayed()
                ? "Delete the result against " + m.getOpponent() + "? Goals credited to scorers will be removed too."
                : "Delete the fixture against " + m.getOpponent() + "?";
        if (FormDialog.confirm(this, "Delete match?", msg, "Delete", true)) {
            store.deleteMatch(m);
            app.changed();
            app.toast("Match deleted");
        }
    }
}
