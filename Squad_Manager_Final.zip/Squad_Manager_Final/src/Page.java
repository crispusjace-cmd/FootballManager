import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Base class for every screen: scrolls vertically, always fills the window width. */
public abstract class Page extends JPanel implements Scrollable {

    protected final AppShell app;
    protected final DataStore store;

    protected Page(AppShell app) {
        super(new BorderLayout(0, 20));
        this.app = app;
        this.store = app.store();
        setOpaque(false);
        setBorder(new EmptyBorder(28, 32, 28, 32));
    }

    /** Re-read the data and update what is on screen. */
    public abstract void refresh();

    protected JPanel header(String title, String subtitle, JComponent... actions) {
        JPanel h = new JPanel(new BorderLayout());
        h.setOpaque(false);
        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        JLabel t = Theme.label(title, 30, Font.BOLD, Theme.TEXT);
        JLabel s = Theme.label(subtitle, 14, Font.PLAIN, Theme.MUTED);
        t.setAlignmentX(LEFT_ALIGNMENT);
        s.setAlignmentX(LEFT_ALIGNMENT);
        text.add(t);
        text.add(Box.createVerticalStrut(4));
        text.add(s);
        h.add(text, BorderLayout.WEST);
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);
        for (JComponent a : actions) right.add(a);
        h.add(right, BorderLayout.EAST);
        return h;
    }

    /** Tiny helper: a transparent panel with the given layout. */
    protected static JPanel box(LayoutManager lm) {
        JPanel p = new JPanel(lm);
        p.setOpaque(false);
        return p;
    }

    protected static Integer parseInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return null; }
    }

    // ---- Scrollable: follow the viewport width, and stretch to its height when there is room
    @Override public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
    @Override public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 28; }
    @Override public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return 200; }
    @Override public boolean getScrollableTracksViewportWidth() { return true; }
    @Override public boolean getScrollableTracksViewportHeight() {
        return getParent() instanceof JViewport && getParent().getHeight() > getPreferredSize().height;
    }
}
