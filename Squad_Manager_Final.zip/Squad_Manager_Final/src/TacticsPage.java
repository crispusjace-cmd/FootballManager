import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.*;
import java.util.List;

/** Choose a formation and build your starting XI by clicking positions on the pitch. */
public class TacticsPage extends Page {

    private final PitchPanel pitch;
    private final java.util.List<Theme.Chip> chips = new ArrayList<>();
    private final StatCard startersCard = new StatCard("Starters", "squad", Theme.GREEN);
    private final StatCard ratingCard = new StatCard("XI rating", "bolt", Theme.GOLD);
    private final StatCard ageCard = new StatCard("XI average age", "training", Theme.BLUE);
    private final Theme.VList bench = new Theme.VList();
    private final JLabel benchCount = Theme.label("", 12, Font.BOLD, Theme.MUTED);
    private boolean updating;

    public TacticsPage(AppShell app) {
        super(app);
        pitch = new PitchPanel(store, true);
        pitch.setOnChange(app::changed);

        Theme.Btn auto = Theme.button("Auto-pick best XI", Theme.Kind.PRIMARY);
        Theme.Btn clear = Theme.button("Clear lineup", Theme.Kind.SECONDARY);
        auto.addActionListener(e -> {
            store.autoPick();
            app.changed();
            app.toast("Best available XI selected");
        });
        clear.addActionListener(e -> {
            store.clearLineup();
            app.changed();
            app.toast("Lineup cleared");
        });
        add(header("Tactics", "Pick a formation, then click any position on the pitch to choose a player.", clear, auto),
                BorderLayout.NORTH);

        // ---- left: pitch
        Theme.Card pitchCard = new Theme.Card("Starting XI");
        pitch.setPreferredSize(new Dimension(520, 640));
        pitchCard.body.add(pitch, BorderLayout.CENTER);

        // ---- right: formation, summary, bench
        Theme.Card formation = new Theme.Card("Formation");
        JPanel chipRow = box(new FlowLayout(FlowLayout.LEFT, 8, 8));
        ButtonGroup group = new ButtonGroup();
        for (String f : Formations.NAMES) {
            Theme.Chip chip = new Theme.Chip(f);
            chip.addActionListener(e -> {
                if (updating) return;
                store.setFormation(f);
                app.changed();
            });
            group.add(chip);
            chips.add(chip);
            chipRow.add(chip);
        }
        formation.body.add(chipRow, BorderLayout.CENTER);

        JPanel summary = box(new GridLayout(1, 3, 12, 0));
        summary.add(startersCard);
        summary.add(ratingCard);
        summary.add(ageCard);

        Theme.Card benchCard = new Theme.Card("Bench and reserves", benchCount);
        JScrollPane sp = Theme.scroll(bench);
        sp.setPreferredSize(new Dimension(300, 240));
        benchCard.body.add(sp, BorderLayout.CENTER);

        JPanel right = box(new BorderLayout(0, 16));
        JPanel rightTop = box(new BorderLayout(0, 16));
        rightTop.add(formation, BorderLayout.NORTH);
        rightTop.add(summary, BorderLayout.SOUTH);
        right.add(rightTop, BorderLayout.NORTH);
        right.add(benchCard, BorderLayout.CENTER);

        JPanel grid = box(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH; c.weighty = 1;
        c.gridx = 0; c.weightx = 0.52; c.insets = new Insets(0, 0, 0, 16);
        grid.add(pitchCard, c);
        c.gridx = 1; c.weightx = 0.48; c.insets = new Insets(0, 0, 0, 0);
        grid.add(right, c);
        add(grid, BorderLayout.CENTER);
    }

    @Override
    public void refresh() {
        updating = true;
        for (Theme.Chip chip : chips) chip.setSelected(chip.getText().equals(store.getFormation()));
        updating = false;

        int n = store.lineupCount();
        startersCard.set(n + "/11", n == 11 ? "lineup complete" : (11 - n) + " positions open");
        ratingCard.set(n == 0 ? "-" : String.format("%.0f", store.lineupAverageRating()), "average rating");
        double age = 0;
        for (int i = 0; i < 11; i++) { Player p = store.lineupPlayer(i); if (p != null) age += p.getAge(); }
        ageCard.set(n == 0 ? "-" : String.format("%.1f", age / n), "years");

        bench.removeAll();
        List<Player> rest = new ArrayList<>();
        for (Player p : store.players().getPlayers()) if (!store.isStarter(p.getShirtNumber())) rest.add(p);
        rest.sort(Comparator.comparingInt(Player::getRating).reversed());
        benchCount.setText(rest.size() + " players");
        for (Player p : rest) bench.addRow(benchRow(p));
        if (rest.isEmpty()) bench.add(Theme.label("Everyone in the squad is starting.", 13, Font.PLAIN, Theme.MUTED));
        pitch.repaint();
        revalidate();
        repaint();
    }

    private JComponent benchRow(Player p) {
        Theme.Rounded row = new Theme.Rounded(new BorderLayout(12, 0), Theme.CARD_ALT, null, 14);
        row.setBorder(new EmptyBorder(9, 12, 9, 14));
        Color role = Theme.roleColor(p.getRole());
        JComponent num = new JComponent() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                Theme.aa(g2);
                g2.setColor(Theme.alpha(role, 36));
                g2.fillOval(0, 0, getWidth() - 1, getHeight() - 1);
                g2.setColor(role);
                g2.setFont(Theme.font(Font.BOLD, 12.5f));
                String t = String.valueOf(p.getShirtNumber());
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(t, (getWidth() - fm.stringWidth(t)) / 2, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(32, 32); }
        };
        JPanel mid = box(new GridLayout(2, 1, 0, 1));
        mid.add(Theme.label(p.getName(), 13.5f, Font.BOLD, Theme.TEXT));
        boolean ok = p.isAvailable();
        mid.add(Theme.label(p.getPosition() + (ok ? "" : "  ·  " + p.getStatus()), 11.5f, Font.PLAIN,
                ok ? Theme.MUTED : Theme.statusColor(p.getStatus())));
        row.add(num, BorderLayout.WEST);
        row.add(mid, BorderLayout.CENTER);
        row.add(Theme.label(String.valueOf(p.getRating()), 15, Font.BOLD, Theme.TEXT), BorderLayout.EAST);
        return row;
    }
}
