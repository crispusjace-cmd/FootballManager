import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.font.TextAttribute;
import java.awt.geom.*;
import java.util.*;
import java.util.List;
import java.util.function.Function;

/**
 * The look of the whole app: colours, fonts and custom-drawn components
 * (cards, buttons, text fields, drop-downs, tables, scroll bars).
 */
public final class Theme {

    private Theme() {}

    // ------------------------------------------------------------------ colours
    public static final Color BG       = new Color(7, 13, 25);
    public static final Color BG_TOP   = new Color(12, 22, 41);
    public static final Color SIDEBAR  = new Color(9, 16, 30);
    public static final Color CARD     = new Color(15, 26, 45);
    public static final Color CARD_ALT = new Color(19, 32, 54);
    public static final Color CARD_HI  = new Color(27, 44, 71);
    public static final Color INPUT    = new Color(9, 17, 31);
    public static final Color BORDER   = new Color(33, 51, 79);
    public static final Color SELECT   = new Color(21, 62, 66);
    public static final Color GREEN    = new Color(34, 214, 120);
    public static final Color GOLD     = new Color(246, 189, 70);
    public static final Color RED      = new Color(244, 90, 90);
    public static final Color BLUE     = new Color(78, 144, 255);
    public static final Color TEXT     = new Color(238, 243, 250);
    public static final Color MUTED    = new Color(133, 153, 182);

    public static Color alpha(Color c, int a) { return new Color(c.getRed(), c.getGreen(), c.getBlue(), a); }

    public static Color roleColor(String role) {
        switch (role) {
            case "GK": return GOLD;
            case "DF": return BLUE;
            case "FW": return new Color(255, 112, 112);
            default:   return GREEN;
        }
    }

    public static Color positionColor(String position) {
        return roleColor(new Player(1, "x", position, 1, 0).getRole());
    }

    public static Color statusColor(String status) {
        if ("Injured".equals(status)) return RED;
        if ("Suspended".equals(status)) return GOLD;
        return GREEN;
    }

    // ------------------------------------------------------------------ fonts
    private static final String FAMILY = pickFamily();

    private static String pickFamily() {
        Set<String> names = new HashSet<>(Arrays.asList(
                GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
        for (String f : new String[]{"Segoe UI", "Inter", "SF Pro Display", "Helvetica Neue", "Roboto", "Arial"}) {
            if (names.contains(f)) return f;
        }
        return Font.SANS_SERIF;
    }

    public static Font font(int style, float size) {
        return new Font(FAMILY, style, 12).deriveFont(style, size);
    }

    public static JLabel label(String text, float size, int style, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font(style, size));
        l.setForeground(color);
        return l;
    }

    /** Small spaced-out uppercase heading, e.g. "SQUAD". */
    public static JLabel caption(String text) {
        JLabel l = new JLabel(text.toUpperCase());
        Map<TextAttribute, Object> attrs = new HashMap<>();
        attrs.put(TextAttribute.TRACKING, 0.08f);
        l.setFont(font(Font.BOLD, 11).deriveFont(attrs));
        l.setForeground(MUTED);
        return l;
    }

    public static void aa(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }

    /** Call once at start-up. */
    public static void install() {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        UIManager.put("PopupMenu.background", CARD);
        UIManager.put("PopupMenu.border", new LineBorder(BORDER));
        UIManager.put("MenuItem.background", CARD);
        UIManager.put("MenuItem.foreground", TEXT);
        UIManager.put("MenuItem.selectionBackground", CARD_HI);
        UIManager.put("MenuItem.selectionForeground", TEXT);
        UIManager.put("MenuItem.disabledForeground", new Color(90, 108, 136));
        UIManager.put("MenuItem.font", font(Font.PLAIN, 13));
        UIManager.put("MenuItem.border", new EmptyBorder(8, 14, 8, 14));
        UIManager.put("Separator.foreground", BORDER);
        UIManager.put("Separator.background", CARD);
        UIManager.put("ToolTip.background", CARD_HI);
        UIManager.put("ToolTip.foreground", TEXT);
        UIManager.put("ToolTip.border", new LineBorder(BORDER));
        UIManager.put("Button.disabledText", MUTED);
        UIManager.put("Table.scrollPaneBorder", new EmptyBorder(0, 0, 0, 0));
    }

    // ------------------------------------------------------------------ cards
    public static class Rounded extends JPanel {
        private Color fill;
        private final Color line;
        private final int arc;

        public Rounded(LayoutManager lm, Color fill, Color line, int arc) {
            super(lm);
            this.fill = fill;
            this.line = line;
            this.arc = arc;
            setOpaque(false);
        }

        public void setFill(Color c) { fill = c; repaint(); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            if (fill != null) {
                g2.setColor(fill);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
            }
            if (line != null) {
                g2.setColor(line);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** A rounded card with an optional small heading and an optional action on the right. */
    public static class Card extends Rounded {
        public final JPanel body = new JPanel(new BorderLayout());

        public Card(String title, JComponent action) {
            super(new BorderLayout(0, 14), CARD, BORDER, 22);
            setBorder(new EmptyBorder(18, 20, 18, 20));
            body.setOpaque(false);
            if (title != null) {
                JPanel head = new JPanel(new BorderLayout());
                head.setOpaque(false);
                head.add(caption(title), BorderLayout.WEST);
                if (action != null) head.add(action, BorderLayout.EAST);
                add(head, BorderLayout.NORTH);
            }
            add(body, BorderLayout.CENTER);
        }

        public Card(String title) { this(title, null); }
    }

    // ------------------------------------------------------------------ buttons
    public enum Kind { PRIMARY, SECONDARY, DANGER, GHOST }

    public static Btn button(String text, Kind kind) { return new Btn(text, kind); }

    public static class Btn extends JButton {
        private final Kind kind;
        private boolean hover, press;
        private int padX = 20, height = 40;

        public Btn(String text, Kind kind) {
            super(text);
            this.kind = kind;
            setFont(font(Font.BOLD, 13));
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; press = false; repaint(); }
                @Override public void mousePressed(MouseEvent e) { press = true; repaint(); }
                @Override public void mouseReleased(MouseEvent e) { press = false; repaint(); }
            });
        }

        public Btn compact() { padX = 14; height = 34; return this; }

        @Override
        public Dimension getPreferredSize() {
            FontMetrics fm = getFontMetrics(getFont());
            return new Dimension(fm.stringWidth(getText()) + padX * 2, height);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            int w = getWidth(), h = getHeight();
            boolean on = isEnabled();
            Color bg = null, line = null, fg = TEXT;
            switch (kind) {
                case PRIMARY:
                    bg = !on ? new Color(28, 64, 58) : press ? new Color(24, 170, 98) : hover ? new Color(72, 232, 150) : GREEN;
                    fg = on ? new Color(4, 24, 15) : MUTED;
                    break;
                case SECONDARY:
                    bg = hover && on ? CARD_HI.brighter() : CARD_HI;
                    line = BORDER;
                    fg = on ? TEXT : MUTED;
                    break;
                case DANGER:
                    bg = alpha(RED, hover && on ? 64 : 34);
                    line = alpha(RED, on ? 130 : 50);
                    fg = on ? new Color(255, 150, 150) : MUTED;
                    break;
                default:
                    bg = hover && on ? CARD_HI : null;
                    fg = on ? TEXT : MUTED;
            }
            if (bg != null) { g2.setColor(bg); g2.fillRoundRect(0, 0, w, h, 14, 14); }
            if (line != null) { g2.setColor(line); g2.drawRoundRect(0, 0, w - 1, h - 1, 14, 14); }
            g2.setFont(getFont());
            g2.setColor(fg);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(getText(), (w - fm.stringWidth(getText())) / 2, (h + fm.getAscent() - fm.getDescent()) / 2);
            g2.dispose();
        }
    }

    /** Pill-shaped toggle used for filters and formation pickers. */
    public static class Chip extends JToggleButton {
        private boolean hover;

        public Chip(String text) {
            super(text);
            setFont(font(Font.BOLD, 12));
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(getFontMetrics(getFont()).stringWidth(getText()) + 30, 34);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            int w = getWidth(), h = getHeight();
            boolean sel = isSelected();
            g2.setColor(sel ? alpha(GREEN, 40) : hover ? CARD_HI : CARD_ALT);
            g2.fillRoundRect(0, 0, w, h, h, h);
            g2.setColor(sel ? alpha(GREEN, 170) : BORDER);
            g2.drawRoundRect(0, 0, w - 1, h - 1, h, h);
            g2.setFont(getFont());
            g2.setColor(sel ? GREEN : MUTED);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(getText(), (w - fm.stringWidth(getText())) / 2, (h + fm.getAscent() - fm.getDescent()) / 2);
            g2.dispose();
        }
    }

    // ------------------------------------------------------------------ inputs
    public static class Field extends JTextField {
        private final String hint;

        public Field(String text) { this(text, ""); }

        public Field(String text, String hint) {
            super(text);
            this.hint = hint;
            setOpaque(false);
            setForeground(TEXT);
            setDisabledTextColor(MUTED);
            setCaretColor(GREEN);
            setSelectionColor(alpha(GREEN, 90));
            setSelectedTextColor(TEXT);
            setFont(font(Font.PLAIN, 14));
            setBorder(new EmptyBorder(10, 14, 10, 14));
            addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent e) { repaint(); }
                @Override public void focusLost(FocusEvent e) { repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            g2.setColor(INPUT);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            g2.dispose();
            super.paintComponent(g);
            g2 = (Graphics2D) g.create();
            aa(g2);
            if (getText().isEmpty() && !hint.isEmpty()) {
                g2.setFont(getFont());
                g2.setColor(new Color(100, 118, 146));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(hint, getInsets().left, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
            }
            g2.setColor(isFocusOwner() ? GREEN : BORDER);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            g2.dispose();
        }
    }

    /** Same look as Field, but hides the characters. */
    public static class PassField extends JPasswordField {
        private final String hint;

        public PassField(String hint) {
            this.hint = hint;
            setOpaque(false);
            setForeground(TEXT);
            setCaretColor(GREEN);
            setSelectionColor(alpha(GREEN, 90));
            setSelectedTextColor(TEXT);
            setFont(font(Font.PLAIN, 14));
            setBorder(new EmptyBorder(10, 14, 10, 14));
            addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent e) { repaint(); }
                @Override public void focusLost(FocusEvent e) { repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            g2.setColor(INPUT);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            g2.dispose();
            super.paintComponent(g);
            g2 = (Graphics2D) g.create();
            aa(g2);
            if (getPassword().length == 0) {
                g2.setFont(getFont());
                g2.setColor(new Color(100, 118, 146));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(hint, getInsets().left, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
            }
            g2.setColor(isFocusOwner() ? GREEN : BORDER);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            g2.dispose();
        }
    }

    public static class Combo extends JComboBox<String> {
        public Combo(String... items) {
            super(items);
            setUI(new ComboUI());
            setOpaque(false);
            setFont(font(Font.PLAIN, 14));
            setForeground(TEXT);
            setBorder(new EmptyBorder(6, 8, 6, 4));
            setMaximumRowCount(10);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setRenderer(new DefaultListCellRenderer() {
                @Override
                public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                              boolean selected, boolean focus) {
                    JLabel l = (JLabel) super.getListCellRendererComponent(list, value, index, selected, false);
                    l.setFont(font(Font.PLAIN, 14));
                    l.setForeground(TEXT);
                    l.setOpaque(index >= 0);
                    l.setBackground(selected ? CARD_HI : CARD);
                    l.setBorder(new EmptyBorder(8, 12, 8, 12));
                    return l;
                }
            });
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            return new Dimension(d.width, 42);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            g2.setColor(INPUT);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            g2.dispose();
            super.paintComponent(g);
            g2 = (Graphics2D) g.create();
            aa(g2);
            g2.setColor(hasFocus() ? GREEN : BORDER);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            g2.dispose();
        }
    }

    private static class ComboUI extends BasicComboBoxUI {
        @Override
        protected JButton createArrowButton() {
            JButton b = new JButton() {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    aa(g2);
                    g2.setColor(MUTED);
                    g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    int cx = getWidth() / 2, cy = getHeight() / 2;
                    g2.drawLine(cx - 4, cy - 2, cx, cy + 2);
                    g2.drawLine(cx, cy + 2, cx + 4, cy - 2);
                    g2.dispose();
                }
            };
            b.setBorder(BorderFactory.createEmptyBorder());
            b.setContentAreaFilled(false);
            b.setFocusPainted(false);
            b.setOpaque(false);
            b.setPreferredSize(new Dimension(30, 30));
            return b;
        }

        @Override
        public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) { }

        @Override
        protected ComboPopup createPopup() {
            BasicComboPopup p = new BasicComboPopup(comboBox) {
                @Override
                protected void configurePopup() {
                    super.configurePopup();
                    setBorder(new LineBorder(BORDER));
                }
            };
            p.getList().setBackground(CARD);
            p.getList().setSelectionBackground(CARD_HI);
            p.getList().setForeground(TEXT);
            return p;
        }
    }

    // ------------------------------------------------------------------ scrolling
    public static JScrollPane scroll(Component view) {
        JScrollPane sp = new JScrollPane(view);
        sp.setBorder(null);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        slim(sp.getVerticalScrollBar());
        return sp;
    }

    public static void slim(JScrollBar sb) {
        sb.setUI(new BasicScrollBarUI() {
            @Override protected JButton createDecreaseButton(int o) { return zero(); }
            @Override protected JButton createIncreaseButton(int o) { return zero(); }
            private JButton zero() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) { }
            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                if (r.isEmpty()) return;
                Graphics2D g2 = (Graphics2D) g.create();
                aa(g2);
                g2.setColor(alpha(MUTED, isThumbRollover() ? 150 : 90));
                g2.fillRoundRect(r.x + 2, r.y + 2, r.width - 4, r.height - 4, 8, 8);
                g2.dispose();
            }
        });
        sb.setPreferredSize(new Dimension(10, 0));
        sb.setOpaque(false);
        sb.setUnitIncrement(22);
    }

    /** A vertical stack of rows that always matches the width of its scroll pane. */
    public static class VList extends JPanel implements Scrollable {
        public VList() {
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            setOpaque(false);
        }

        public void addRow(JComponent row) {
            row.setAlignmentX(Component.LEFT_ALIGNMENT);
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, row.getPreferredSize().height));
            add(row);
            add(Box.createVerticalStrut(10));
        }

        @Override public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        @Override public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 24; }
        @Override public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return 120; }
        @Override public boolean getScrollableTracksViewportWidth() { return true; }
        @Override public boolean getScrollableTracksViewportHeight() { return false; }
    }

    // ------------------------------------------------------------------ tables
    public static Color rowBg(JTable t, int row, boolean selected) {
        return selected ? SELECT : (row % 2 == 0 ? CARD : CARD_ALT);
    }

    public static void styleTable(JTable t) {
        t.setBackground(CARD);
        t.setForeground(TEXT);
        t.setFont(font(Font.PLAIN, 14));
        t.setRowHeight(48);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setSelectionBackground(SELECT);
        t.setSelectionForeground(TEXT);
        t.setFillsViewportHeight(true);
        t.setBorder(null);
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JTableHeader h = t.getTableHeader();
        h.setReorderingAllowed(false);
        h.setPreferredSize(new Dimension(0, 44));
        h.setDefaultRenderer(new HeaderRenderer());
        h.setBackground(CARD);
        t.setDefaultRenderer(Object.class, new TextRenderer(false));
        t.setDefaultRenderer(Integer.class, new TextRenderer(false));
    }

    public static JScrollPane tableScroll(JTable t) {
        JScrollPane sp = scroll(t);
        sp.setBorder(null);
        sp.setViewportBorder(null);
        sp.getViewport().setOpaque(true);
        sp.getViewport().setBackground(CARD);
        sp.setBackground(CARD);
        slim(sp.getVerticalScrollBar());
        return sp;
    }

    private static class HeaderRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
            super.getTableCellRendererComponent(t, v, false, false, r, c);
            setText(v == null ? "" : v.toString().toUpperCase());
            setOpaque(true);
            setBackground(CARD);
            setForeground(MUTED);
            Map<TextAttribute, Object> attrs = new HashMap<>();
            attrs.put(TextAttribute.TRACKING, 0.06f);
            setFont(font(Font.BOLD, 11).deriveFont(attrs));
            setBorder(new CompoundBorder(new MatteBorder(0, 0, 1, 0, BORDER), new EmptyBorder(0, 16, 0, 10)));
            Class<?> cls = t.getColumnClass(c);
            setHorizontalAlignment(Integer.class.equals(cls) ? CENTER : LEFT);
            return this;
        }
    }

    public static class TextRenderer extends DefaultTableCellRenderer {
        private final boolean bold;

        public TextRenderer(boolean bold) { this.bold = bold; }

        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean f, int r, int c) {
            super.getTableCellRendererComponent(t, v, false, false, r, c);
            setOpaque(true);
            setBackground(rowBg(t, r, sel));
            setForeground(bold ? TEXT : new Color(210, 221, 238));
            setFont(font(bold ? Font.BOLD : Font.PLAIN, 14));
            setBorder(new EmptyBorder(0, 16, 0, 10));
            setHorizontalAlignment(v instanceof Integer ? CENTER : LEFT);
            return this;
        }
    }

    /** Draws a coloured pill (e.g. position or status) inside a table cell. */
    public static class PillRenderer extends DefaultTableCellRenderer {
        private final Function<String, Color> colorFor;
        private Color pill = GREEN, bg = CARD;
        private String txt = "";

        public PillRenderer(Function<String, Color> colorFor) { this.colorFor = colorFor; }

        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean f, int r, int c) {
            txt = v == null ? "" : v.toString();
            pill = colorFor.apply(txt);
            bg = rowBg(t, r, sel);
            return this;
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            g2.setColor(bg);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setFont(font(Font.BOLD, 12));
            FontMetrics fm = g2.getFontMetrics();
            int pw = fm.stringWidth(txt) + 24, ph = 26, x = 14, y = (getHeight() - ph) / 2;
            g2.setColor(alpha(pill, 36));
            g2.fillRoundRect(x, y, pw, ph, ph, ph);
            g2.setColor(alpha(pill, 140));
            g2.drawRoundRect(x, y, pw, ph, ph, ph);
            g2.setColor(pill);
            g2.drawString(txt, x + 12, y + (ph + fm.getAscent() - fm.getDescent()) / 2);
            g2.dispose();
        }
    }

    /** Number plus a small progress bar for the player rating column. */
    public static class RatingRenderer extends DefaultTableCellRenderer {
        private int value;
        private Color bg = CARD;

        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean f, int r, int c) {
            value = v instanceof Integer ? (Integer) v : 0;
            bg = rowBg(t, r, sel);
            return this;
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            g2.setColor(bg);
            g2.fillRect(0, 0, getWidth(), getHeight());
            Color col = value >= 80 ? GREEN : value >= 70 ? BLUE : GOLD;
            g2.setFont(font(Font.BOLD, 14));
            g2.setColor(TEXT);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(String.valueOf(value), 16, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
            int bx = 50, bw = Math.max(20, getWidth() - bx - 24), by = getHeight() / 2 - 3;
            g2.setColor(new Color(255, 255, 255, 22));
            g2.fillRoundRect(bx, by, bw, 6, 6, 6);
            g2.setColor(col);
            double ratio = Math.max(0.05, Math.min(1.0, (value - 40) / 59.0));
            g2.fillRoundRect(bx, by, (int) (bw * ratio), 6, 6, 6);
            g2.dispose();
        }
    }
}
