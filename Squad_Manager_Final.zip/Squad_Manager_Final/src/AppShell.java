import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedHashMap;
import java.util.Map;

/** The whole window content: sidebar on the left, the selected page on the right. */
public class AppShell extends JPanel {

    private final DataStore store;
    private final CardLayout cards = new CardLayout();
    private final JPanel stack = new JPanel(cards);
    private final Map<String, Page> pages = new LinkedHashMap<>();
    private final Map<String, NavButton> navButtons = new LinkedHashMap<>();
    private JLabel sideTeam, sideInfo;
    private final String user;
    private final Runnable onLogout;

    public AppShell(DataStore store) { this(store, null, null); }

    public AppShell(DataStore store, String user, Runnable onLogout) {
        this.store = store;
        this.user = user;
        this.onLogout = onLogout;
        setLayout(new BorderLayout());
        stack.setOpaque(false);

        addPage("Dashboard", "dashboard", new DashboardPage(this));
        addPage("Squad", "squad", new SquadPage(this));
        addPage("Tactics", "tactics", new TacticsPage(this));
        addPage("Match Day", "match", new MatchDayPage(this));
        addPage("Training", "training", new TrainingPage(this));

        add(buildSidebar(), BorderLayout.WEST);
        add(stack, BorderLayout.CENTER);
        refreshAll();
        navigate("Dashboard");
    }

    public DataStore store() { return store; }

    private void addPage(String key, String icon, Page page) {
        pages.put(key, page);
        stack.add(Theme.scroll(page), key);
    }

    public void navigate(String key) {
        cards.show(stack, key);
        for (Map.Entry<String, NavButton> e : navButtons.entrySet()) e.getValue().setActive(e.getKey().equals(key));
        pages.get(key).refresh();
    }

    /** Call after any change: saves to disk and updates every page. */
    public void changed() {
        store.save();
        refreshAll();
    }

    private void refreshAll() {
        for (Page p : pages.values()) p.refresh();
        if (sideTeam != null) {
            sideTeam.setText(store.getTeamName());
            sideInfo.setText(store.players().getTotalPlayers() + " players  ·  " + store.getFormation());
        }
        repaint();
    }

    // ------------------------------------------------------------------ toast
    public void toast(String message, boolean error) {
        JRootPane rp = getRootPane();
        if (rp == null) return;
        JLayeredPane lp = rp.getLayeredPane();
        Color accent = error ? Theme.RED : Theme.GREEN;
        Theme.Rounded t = new Theme.Rounded(new BorderLayout(12, 0), Theme.CARD_HI, accent, 16);
        t.setBorder(new EmptyBorder(13, 18, 13, 20));
        JLabel dot = new JLabel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                Theme.aa(g2);
                g2.setColor(accent);
                g2.fillOval(0, 3, 10, 10);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(10, 16); }
        };
        t.add(dot, BorderLayout.WEST);
        t.add(Theme.label(message, 13.5f, Font.BOLD, Theme.TEXT), BorderLayout.CENTER);
        Dimension d = t.getPreferredSize();
        t.setBounds(lp.getWidth() - d.width - 30, lp.getHeight() - d.height - 30, d.width, d.height);
        lp.add(t, JLayeredPane.POPUP_LAYER);
        lp.repaint();
        Timer timer = new Timer(2600, e -> { lp.remove(t); lp.repaint(); });
        timer.setRepeats(false);
        timer.start();
    }

    public void toast(String message) { toast(message, false); }

    // ------------------------------------------------------------------ sidebar
    private JPanel buildSidebar() {
        JPanel side = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(Theme.SIDEBAR);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(Theme.BORDER);
                g.fillRect(getWidth() - 1, 0, 1, getHeight());
            }
        };
        side.setOpaque(false);
        side.setPreferredSize(new Dimension(246, 0));
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setBorder(new EmptyBorder(26, 18, 20, 18));

        // logo
        JPanel logo = Page.box(new BorderLayout(12, 0));
        logo.setAlignmentX(LEFT_ALIGNMENT);
        JComponent mark = new JComponent() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                Theme.aa(g2);
                g2.setPaint(new GradientPaint(0, 0, new Color(52, 232, 140), 0, getHeight(), new Color(16, 160, 96)));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                Icons.draw("ball", g2, 8, 8, getWidth() - 16, new Color(4, 28, 18));
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(42, 42); }
        };
        JPanel names = Page.box(new GridLayout(2, 1, 0, 0));
        names.add(Theme.label("Squad Manager", 17, Font.BOLD, Theme.TEXT));
        names.add(Theme.label("Build. Prepare. Dominate.", 11, Font.PLAIN, Theme.MUTED));
        logo.add(mark, BorderLayout.WEST);
        logo.add(names, BorderLayout.CENTER);
        logo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        side.add(logo);
        side.add(Box.createVerticalStrut(34));

        JLabel menu = Theme.caption("Menu");
        menu.setAlignmentX(LEFT_ALIGNMENT);
        menu.setBorder(new EmptyBorder(0, 12, 0, 0));
        side.add(menu);
        side.add(Box.createVerticalStrut(10));

        String[][] items = {{"Dashboard", "dashboard"}, {"Squad", "squad"}, {"Tactics", "tactics"},
                {"Match Day", "match"}, {"Training", "training"}};
        for (String[] it : items) {
            NavButton b = new NavButton(it[0], it[1]);
            b.setAlignmentX(LEFT_ALIGNMENT);
            b.addActionListener(e -> navigate(it[0]));
            navButtons.put(it[0], b);
            side.add(b);
            side.add(Box.createVerticalStrut(6));
        }
        side.add(Box.createVerticalGlue());

        // team card
        Theme.Rounded team = new Theme.Rounded(new BorderLayout(0, 3), Theme.CARD, Theme.BORDER, 18);
        team.setBorder(new EmptyBorder(14, 16, 14, 16));
        sideTeam = Theme.label(store.getTeamName(), 14, Font.BOLD, Theme.TEXT);
        sideInfo = Theme.label(" ", 12, Font.PLAIN, Theme.MUTED);
        team.add(sideTeam, BorderLayout.NORTH);
        team.add(sideInfo, BorderLayout.CENTER);
        team.setAlignmentX(LEFT_ALIGNMENT);
        team.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        side.add(team);
        side.add(Box.createVerticalStrut(12));

        JPanel tools = Page.box(new GridLayout(1, 2, 8, 0));
        Theme.Btn demo = Theme.button("Demo data", Theme.Kind.GHOST).compact();
        Theme.Btn clear = Theme.button("Clear all", Theme.Kind.GHOST).compact();
        demo.addActionListener(e -> {
            if (FormDialog.confirm(this, "Load demo data?", "This replaces everything with a sample squad, fixtures and training sessions.", "Load demo", false)) {
                store.seedDemo();
                changed();
                toast("Demo data loaded");
            }
        });
        clear.addActionListener(e -> {
            if (FormDialog.confirm(this, "Clear everything?", "All players, matches and training sessions will be deleted. You can then add your own real squad.", "Clear all", true)) {
                store.clearAll();
                changed();
                toast("Everything cleared. Add your first player!");
            }
        });
        tools.add(demo);
        tools.add(clear);
        tools.setAlignmentX(LEFT_ALIGNMENT);
        tools.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        side.add(tools);

        if (user != null && onLogout != null) {
            side.add(Box.createVerticalStrut(10));
            JLabel who = Theme.label("Signed in as " + user, 12, Font.PLAIN, Theme.MUTED);
            who.setAlignmentX(LEFT_ALIGNMENT);
            who.setBorder(new EmptyBorder(0, 4, 6, 0));
            side.add(who);
            Theme.Btn out = Theme.button("Log out", Theme.Kind.SECONDARY).compact();
            out.setAlignmentX(LEFT_ALIGNMENT);
            out.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
            out.addActionListener(e -> onLogout.run());
            side.add(out);
        }
        return side;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setPaint(new GradientPaint(0, 0, Theme.BG_TOP, 0, getHeight(), Theme.BG));
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.dispose();
    }

    // ------------------------------------------------------------------ nav button
    private static class NavButton extends JButton {
        private final String icon;
        private boolean active, hover;

        NavButton(String text, String icon) {
            super(text);
            this.icon = icon;
            setFont(Theme.font(Font.BOLD, 14));
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setHorizontalAlignment(SwingConstants.LEFT);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(200, 46));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        void setActive(boolean a) { active = a; repaint(); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            Theme.aa(g2);
            int w = getWidth(), h = getHeight();
            if (active) {
                g2.setColor(Theme.alpha(Theme.GREEN, 30));
                g2.fillRoundRect(0, 0, w, h, 14, 14);
                g2.setColor(Theme.GREEN);
                g2.fillRoundRect(0, h / 2 - 11, 4, 22, 4, 4);
            } else if (hover) {
                g2.setColor(Theme.CARD);
                g2.fillRoundRect(0, 0, w, h, 14, 14);
            }
            Color c = active ? Theme.GREEN : hover ? Theme.TEXT : Theme.MUTED;
            Icons.draw(icon, g2, 16, (h - 22) / 2f, 22, c);
            g2.setFont(getFont());
            g2.setColor(c);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(getText(), 52, (h + fm.getAscent() - fm.getDescent()) / 2);
            g2.dispose();
        }
    }
}
