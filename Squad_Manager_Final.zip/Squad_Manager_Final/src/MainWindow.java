import javax.swing.*;
import java.awt.*;

/**
 * Football Squad Manager - application window.
 * Shows the login screen first, then the main app (AppShell).
 */
public class MainWindow extends JFrame {

    private static final long serialVersionUID = 1L;

    private final AuthService auth = new AuthService();
    private final DataStore store = DataStore.load();

    public MainWindow() {
        setTitle("Squad Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1100, 700));
        setSize(1440, 880);
        setLocationRelativeTo(null);
        showLogin();
        // save once more when the window closes
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosing(java.awt.event.WindowEvent e) { store.save(); }
        });
    }

    private void showLogin() {
        setContentPane(new LoginPanel(auth, this::showApp));
        revalidate();
        repaint();
    }

    private void showApp(String user) {
        setContentPane(new AppShell(store, user, () -> {
            store.save();
            showLogin();
        }));
        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        Theme.install();
        SwingUtilities.invokeLater(() -> new MainWindow().setVisible(true));
    }
}
