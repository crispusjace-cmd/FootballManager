import java.util.ArrayList;
import java.util.Iterator;

/**
 * Holds every registered player and provides add / remove / search / update.
 */
public class PlayerManager {

    private final ArrayList<Player> players = new ArrayList<>();

    // 1. ADD PLAYER
    public boolean addPlayer(Player player) {
        if (player == null) return false;

        if (player.getShirtNumber() <= 0
                || player.getName() == null || player.getName().trim().isEmpty()
                || player.getPosition() == null || player.getPosition().trim().isEmpty()
                || player.getAge() <= 0
                || player.getGoals() < 0
                || player.getRating() < 1 || player.getRating() > 99) {
            return false;
        }

        // Prevent duplicate shirt numbers
        if (searchPlayer(player.getShirtNumber()) != null) return false;

        players.add(player);
        return true;
    }

    // 2. REMOVE PLAYER
    public boolean removePlayer(int shirtNumber) {
        Iterator<Player> it = players.iterator();
        while (it.hasNext()) {
            if (it.next().getShirtNumber() == shirtNumber) {
                it.remove();
                return true;
            }
        }
        return false;
    }

    // 3. SEARCH BY SHIRT NUMBER
    public Player searchPlayer(int shirtNumber) {
        for (Player p : players) {
            if (p.getShirtNumber() == shirtNumber) return p;
        }
        return null;
    }

    // 4. SEARCH BY NAME (partial, case-insensitive)
    public ArrayList<Player> searchPlayers(String name) {
        ArrayList<Player> results = new ArrayList<>();
        if (name == null || name.trim().isEmpty()) return results;
        String key = name.trim().toLowerCase();
        for (Player p : players) {
            if (p.getName().toLowerCase().contains(key)) results.add(p);
        }
        return results;
    }

    // 5. UPDATE (original 5-argument version, keeps rating and status)
    public boolean updatePlayer(int shirtNumber, String name, String position, int age, int goals) {
        Player p = searchPlayer(shirtNumber);
        if (p == null) return false;
        return updatePlayer(shirtNumber, name, position, age, goals, p.getRating(), p.getStatus());
    }

    // 5b. UPDATE (full version)
    public boolean updatePlayer(int shirtNumber, String name, String position, int age,
                                int goals, int rating, String status) {
        Player p = searchPlayer(shirtNumber);
        if (p == null) return false;

        if (name == null || name.trim().isEmpty()
                || position == null || position.trim().isEmpty()
                || age <= 0 || goals < 0 || rating < 1 || rating > 99
                || status == null) {
            return false;
        }

        p.setName(name.trim());
        p.setPosition(position.trim());
        p.setAge(age);
        p.setGoals(goals);
        p.setRating(rating);
        p.setStatus(status);
        return true;
    }

    // 6. GET ALL PLAYERS (a copy, so the list cannot be changed from outside)
    public ArrayList<Player> getPlayers() {
        return new ArrayList<>(players);
    }

    public void clear() { players.clear(); }

    // 7. DISPLAY ALL (console)
    public void displayAllPlayers() {
        if (players.isEmpty()) {
            System.out.println("No players registered.");
            return;
        }
        for (Player p : players) {
            System.out.println("-------------------");
            p.displayPlayer();
        }
    }

    // 8. COUNTS
    public int getTotalPlayers() { return players.size(); }

    public int getPlayersByPosition(String position) {
        if (position == null) return 0;
        int count = 0;
        for (Player p : players) {
            if (p.getPosition().equalsIgnoreCase(position.trim())) count++;
        }
        return count;
    }

    public int getGoalkeeperCount() { return getPlayersByPosition("Goalkeeper"); }
    public int getDefenderCount()   { return getPlayersByPosition("Defender"); }
    public int getMidfielderCount() { return getPlayersByPosition("Midfielder"); }
    public int getForwardCount()    { return getPlayersByPosition("Forward"); }

    public int getCountByStatus(String status) {
        int count = 0;
        for (Player p : players) {
            if (p.getStatus().equalsIgnoreCase(status)) count++;
        }
        return count;
    }

    public double getAverageAge() {
        if (players.isEmpty()) return 0;
        double sum = 0;
        for (Player p : players) sum += p.getAge();
        return sum / players.size();
    }
}
