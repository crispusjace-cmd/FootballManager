import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

/** Plan training sessions and see the weekly workload. */
public class TrainingPage extends Page {

    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("EEE d MMM", Locale.ENGLISH);

    private final StatCard sessionsCard = new StatCard("Sessions this week", "training", Theme.GREEN);
    private final StatCard minutesCard = new StatCard("Minutes this week", "bolt", Theme.GOLD);
    private final StatCard nextCard = new StatCard("Next session", "tactics", Theme.BLUE);
    private final StatCard totalCard = new StatCard("All sessions", "dashboard", new Color(255, 112, 112));
    private final Charts.WeekChart chart = new Charts.WeekChart();
    private final JLabel legendNote = Theme.label("Bar colour shows the hardest session of the day.", 12, Font.PLAIN, Theme.MUTED);

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"Date", "Type", "Min", "Intensity", "Notes"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
        @Override public Class<?> getColumnClass(int c) { return c == 2 ? Integer.class : String.class; }
    };
    private final JTable table = new JTable(model);
    private List<TrainingSession> shown = new ArrayList<>();
    private final Theme.Btn deleteBtn = Theme.button("Delete selected", Theme.Kind.DANGER).compact();
    private final JPanel tableCards = new JPanel(new CardLayout());

    public TrainingPage(AppShell app) {
        super(app);
        Theme.Btn add = Theme.button("+  Add session", Theme.Kind.PRIMARY);
        add.addActionListener(e -> sessionForm());
        add(header("Training", "Plan the week and keep an eye on player workload.", add), BorderLayout.NORTH);

        JPanel stats = box(new GridLayout(1, 4, 16, 0));
        stats.add(sessionsCard);
        stats.add(minutesCard);
        stats.add(nextCard);
        stats.add(totalCard);

        // chart card
        Theme.Card chartCard = new Theme.Card("Planned duration this week (minutes)");
        JPanel cb = box(new BorderLayout(0, 10));
        chart.setPreferredSize(new Dimension(360, 300));
        cb.add(chart, BorderLayout.CENTER);
        JPanel key = box(new FlowLayout(FlowLayout.LEFT, 14, 0));
        key.add(keyDot("Low", Theme.GREEN));
        key.add(keyDot("Medium", Theme.GOLD));
        key.add(keyDot("High", Theme.RED));
        cb.add(key, BorderLayout.SOUTH);
        chartCard.body.add(cb, BorderLayout.CENTER);

        // table card
        deleteBtn.setEnabled(false);
        deleteBtn.addActionListener(e -> deleteSelected());
        Theme.Card listCard = new Theme.Card("All sessions", deleteBtn);
        Theme.styleTable(table);
        TableColumnModel cm = table.getColumnModel();
        cm.getColumn(0).setCellRenderer(new Theme.TextRenderer(true));
        cm.getColumn(1).setCellRenderer(new Theme.PillRenderer(t -> Theme.BLUE));
        cm.getColumn(3).setCellRenderer(new Theme.PillRenderer(t ->
                t.equals("High") ? Theme.RED : t.equals("Medium") ? Theme.GOLD : Theme.GREEN));
        int[] widths = {120, 140, 80, 120, 220};
        for (int i = 0; i < widths.length; i++) cm.getColumn(i).setPreferredWidth(widths[i]);
        table.getSelectionModel().addListSelectionListener(e -> deleteBtn.setEnabled(table.getSelectedRow() >= 0));
        JPanel empty = box(new GridBagLayout());
        empty.add(Theme.label("No sessions yet. Click \"Add session\" to plan one.", 14, Font.PLAIN, Theme.MUTED));
        tableCards.setOpaque(false);
        tableCards.add(Theme.tableScroll(table), "table");
        tableCards.add(empty, "empty");
        listCard.body.add(tableCards, BorderLayout.CENTER);
        listCard.setPreferredSize(new Dimension(560, 360));

        JPanel cols = box(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH; c.weighty = 1;
        c.gridx = 0; c.weightx = 0.42; c.insets = new Insets(0, 0, 0, 16);
        cols.add(chartCard, c);
        c.gridx = 1; c.weightx = 0.58; c.insets = new Insets(0, 0, 0, 0);
        cols.add(listCard, c);

        JPanel center = box(new BorderLayout(0, 16));
        center.add(stats, BorderLayout.NORTH);
        center.add(cols, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);
    }

    private JComponent keyDot(String text, Color c) {
        JPanel p = box(new FlowLayout(FlowLayout.LEFT, 6, 0));
        JComponent dot = new JComponent() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                Theme.aa(g2);
                g2.setColor(c);
                g2.fillOval(0, 2, 9, 9);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(9, 16); }
        };
        p.add(dot);
        p.add(Theme.label(text, 12, Font.PLAIN, Theme.MUTED));
        return p;
    }

    @Override
    public void refresh() {
        LocalDate start = Charts.WeekChart.weekStart(), end = start.plusDays(6), today = LocalDate.now();
        int mins = 0, count = 0;
        for (TrainingSession s : store.sessions()) {
            if (!s.getDate().isBefore(start) && !s.getDate().isAfter(end)) { mins += s.getMinutes(); count++; }
        }
        sessionsCard.set(String.valueOf(count), "Mon to Sun");
        minutesCard.set(String.valueOf(mins), count == 0 ? "nothing planned" : "about " + mins / Math.max(1, count) + " min per session");
        TrainingSession next = null;
        for (TrainingSession s : store.sortedSessions()) {
            if (!s.getDate().isBefore(today)) { next = s; break; }
        }
        if (next == null) nextCard.set("None", "add a session");
        else nextCard.set(next.getType(), next.getDate().format(DAY) + "  ·  " + next.getMinutes() + " min");
        totalCard.set(String.valueOf(store.sessions().size()), "in your plan");
        chart.set(store.sessions());

        shown = store.sortedSessions();
        model.setRowCount(0);
        for (TrainingSession s : shown) {
            model.addRow(new Object[]{s.getDate().format(DAY), s.getType(), s.getMinutes(), s.getIntensity(), s.getNotes()});
        }
        ((CardLayout) tableCards.getLayout()).show(tableCards, shown.isEmpty() ? "empty" : "table");
        deleteBtn.setEnabled(false);
        revalidate();
        repaint();
    }

    private void deleteSelected() {
        int r = table.getSelectedRow();
        if (r < 0 || r >= shown.size()) return;
        TrainingSession s = shown.get(r);
        if (FormDialog.confirm(this, "Delete session?", s.getType() + " on " + s.getDate().format(DAY) + " will be removed from the plan.", "Delete", true)) {
            store.sessions().remove(s);
            app.changed();
            app.toast("Session deleted");
        }
    }

    private void sessionForm() {
        Theme.Combo type = new Theme.Combo(TrainingSession.TYPES);
        Theme.Field date = new Theme.Field(LocalDate.now().toString(), "YYYY-MM-DD");
        Theme.Field minutes = new Theme.Field("60", "e.g. 60");
        Theme.Combo intensity = new Theme.Combo(TrainingSession.INTENSITIES);
        intensity.setSelectedItem("Medium");
        Theme.Field notes = new Theme.Field("", "Optional, e.g. pressing drills");
        boolean ok = FormDialog.show(this, "Add training session", "Plan a session for the squad.", "Add session",
                new String[]{"~Type", "~Intensity", "~Date (YYYY-MM-DD)", "~Minutes", "Notes"},
                new JComponent[]{type, intensity, date, minutes, notes},
                () -> {
                    try { LocalDate.parse(date.getText().trim()); }
                    catch (Exception ex) { return "Date must look like 2026-12-05 (year-month-day)."; }
                    Integer m = parseInt(minutes.getText());
                    if (m == null || m < 10 || m > 240) return "Minutes must be a whole number between 10 and 240.";
                    return null;
                });
        if (ok) {
            store.sessions().add(new TrainingSession((String) type.getSelectedItem(), LocalDate.parse(date.getText().trim()),
                    parseInt(minutes.getText()), (String) intensity.getSelectedItem(), notes.getText().trim()));
            app.changed();
            app.toast("Training session added");
        }
    }
}
