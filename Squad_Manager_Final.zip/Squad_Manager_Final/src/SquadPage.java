import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

/** Squad management: add, edit, delete, search and filter players. */
public class SquadPage extends Page {

    private final StatCard total = new StatCard("Total players", "squad", Theme.GREEN);
    private final StatCard gk = new StatCard("Goalkeepers", "text:GK", Theme.GOLD);
    private final StatCard df = new StatCard("Defenders", "text:DF", Theme.BLUE);
    private final StatCard mf = new StatCard("Midfielders", "text:MF", Theme.GREEN);
    private final StatCard fw = new StatCard("Forwards", "text:FW", new Color(255, 112, 112));

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"No.", "Player", "Position", "Age", "Goals", "Rating", "Status"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
        @Override public Class<?> getColumnClass(int c) {
            return (c == 0 || c == 3 || c == 4 || c == 5) ? Integer.class : String.class;
        }
    };
    private final JTable table = new JTable(model);
    private final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
    private final Theme.Field search = new Theme.Field("", "Search players by name or number...");
    private String positionFilter = "All";
    private final Theme.Btn editBtn = Theme.button("Edit", Theme.Kind.SECONDARY);
    private final Theme.Btn deleteBtn = Theme.button("Delete", Theme.Kind.DANGER);
    private final JPanel tableCards = new JPanel(new CardLayout());
    private final JLabel emptyText = Theme.label("", 15, Font.PLAIN, Theme.MUTED);

    public SquadPage(AppShell app) {
        super(app);
        Theme.Btn add = Theme.button("+  Add Player", Theme.Kind.PRIMARY);
        add.addActionListener(e -> playerForm(null));
        add(header("Squad", "Manage your players, positions and fitness.", add), BorderLayout.NORTH);

        JPanel stats = box(new GridLayout(1, 5, 16, 0));
        for (StatCard c : new StatCard[]{total, gk, df, mf, fw}) stats.add(c);

        // ---- filter bar
        JPanel bar = box(new BorderLayout(14, 0));
        search.setPreferredSize(new Dimension(320, 42));
        JPanel left = box(new FlowLayout(FlowLayout.LEFT, 8, 0));
        ButtonGroup group = new ButtonGroup();
        for (String f : new String[]{"All", "Goalkeeper", "Defender", "Midfielder", "Forward"}) {
            Theme.Chip chip = new Theme.Chip(f);
            if (f.equals("All")) chip.setSelected(true);
            chip.addActionListener(e -> { positionFilter = f; applyFilter(); });
            group.add(chip);
            left.add(chip);
        }
        JPanel searchWrap = box(new BorderLayout());
        searchWrap.add(search, BorderLayout.CENTER);
        searchWrap.setPreferredSize(new Dimension(320, 42));
        JPanel right = box(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        editBtn.compact();
        deleteBtn.compact();
        right.add(editBtn);
        right.add(deleteBtn);
        bar.add(searchWrap, BorderLayout.WEST);
        bar.add(left, BorderLayout.CENTER);
        bar.add(right, BorderLayout.EAST);

        // ---- table
        Theme.styleTable(table);
        table.setRowSorter(sorter);
        table.getTableHeader().setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        TableColumnModel cm = table.getColumnModel();
        cm.getColumn(0).setCellRenderer(new Theme.TextRenderer(true));
        cm.getColumn(1).setCellRenderer(new Theme.TextRenderer(true));
        cm.getColumn(2).setCellRenderer(new Theme.PillRenderer(Theme::positionColor));
        cm.getColumn(5).setCellRenderer(new Theme.RatingRenderer());
        cm.getColumn(6).setCellRenderer(new Theme.PillRenderer(Theme::statusColor));
        int[] widths = {70, 260, 150, 70, 80, 190, 140};
        for (int i = 0; i < widths.length; i++) cm.getColumn(i).setPreferredWidth(widths[i]);
        table.getSelectionModel().addListSelectionListener(e -> updateButtons());
        table.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && table.getSelectedRow() >= 0) editSelected();
            }
        });
        editBtn.addActionListener(e -> editSelected());
        deleteBtn.addActionListener(e -> deleteSelected());
        search.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { applyFilter(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { applyFilter(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { applyFilter(); }
        });

        Theme.Card tableCard = new Theme.Card(null);
        tableCard.setBorder(new EmptyBorder(10, 10, 10, 10));
        JPanel emptyPanel = box(new GridBagLayout());
        emptyPanel.add(emptyText);
        tableCards.setOpaque(false);
        tableCards.add(Theme.tableScroll(table), "table");
        tableCards.add(emptyPanel, "empty");
        tableCard.body.add(tableCards, BorderLayout.CENTER);

        JPanel center = box(new BorderLayout(0, 16));
        JPanel top = box(new BorderLayout(0, 16));
        top.add(stats, BorderLayout.NORTH);
        top.add(bar, BorderLayout.SOUTH);
        center.add(top, BorderLayout.NORTH);
        tableCard.setPreferredSize(new Dimension(300, 440));
        center.add(tableCard, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);
        updateButtons();
    }

    @Override
    public void refresh() {
        PlayerManager pm = store.players();
        total.set(String.valueOf(pm.getTotalPlayers()), "avg age " + String.format("%.1f", pm.getAverageAge()));
        gk.set(String.valueOf(pm.getGoalkeeperCount()), "in squad");
        df.set(String.valueOf(pm.getDefenderCount()), "in squad");
        mf.set(String.valueOf(pm.getMidfielderCount()), "in squad");
        fw.set(String.valueOf(pm.getForwardCount()), "in squad");

        Integer selected = null;
        int vr = table.getSelectedRow();
        if (vr >= 0) selected = (Integer) model.getValueAt(table.convertRowIndexToModel(vr), 0);
        model.setRowCount(0);
        for (Player p : pm.getPlayers()) {
            model.addRow(new Object[]{p.getShirtNumber(), p.getName(), p.getPosition(), p.getAge(),
                    p.getGoals(), p.getRating(), p.getStatus()});
        }
        if (selected != null) {
            for (int i = 0; i < table.getRowCount(); i++) {
                if (selected.equals(model.getValueAt(table.convertRowIndexToModel(i), 0))) {
                    table.setRowSelectionInterval(i, i);
                    break;
                }
            }
        }
        applyFilter();
    }

    private void applyFilter() {
        final String text = search.getText().trim().toLowerCase();
        final String pos = positionFilter;
        sorter.setRowFilter(new RowFilter<DefaultTableModel, Integer>() {
            @Override
            public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> e) {
                boolean okPos = pos.equals("All") || pos.equals(e.getStringValue(2));
                boolean okText = text.isEmpty()
                        || e.getStringValue(1).toLowerCase().contains(text)
                        || e.getStringValue(0).equals(text);
                return okPos && okText;
            }
        });
        boolean empty = table.getRowCount() == 0;
        emptyText.setText(store.players().getTotalPlayers() == 0
                ? "No players yet. Click \"Add Player\" to register your first one."
                : "No players match your search.");
        ((CardLayout) tableCards.getLayout()).show(tableCards, empty ? "empty" : "table");
        updateButtons();
    }

    private void updateButtons() {
        boolean sel = table.getSelectedRow() >= 0;
        editBtn.setEnabled(sel);
        deleteBtn.setEnabled(sel);
    }

    private Player selectedPlayer() {
        int vr = table.getSelectedRow();
        if (vr < 0) return null;
        int shirt = (Integer) model.getValueAt(table.convertRowIndexToModel(vr), 0);
        return store.players().searchPlayer(shirt);
    }

    private void editSelected() {
        Player p = selectedPlayer();
        if (p != null) playerForm(p);
    }

    private void deleteSelected() {
        Player p = selectedPlayer();
        if (p == null) return;
        if (FormDialog.confirm(this, "Delete player?", "Remove #" + p.getShirtNumber() + " " + p.getName()
                + " from the squad? This also removes him from your starting XI.", "Delete", true)) {
            store.players().removePlayer(p.getShirtNumber());
            store.cleanLineup();
            app.changed();
            app.toast(p.getName() + " removed");
        }
    }

    /** Add (existing == null) or edit a player. */
    private void playerForm(Player existing) {
        boolean adding = existing == null;
        Theme.Field shirt = new Theme.Field(adding ? "" : String.valueOf(existing.getShirtNumber()), "e.g. 10");
        shirt.setEnabled(adding);
        Theme.Field name = new Theme.Field(adding ? "" : existing.getName(), "Full name");
        Theme.Combo pos = new Theme.Combo(Player.POSITIONS);
        Theme.Field age = new Theme.Field(adding ? "" : String.valueOf(existing.getAge()), "e.g. 22");
        Theme.Field goals = new Theme.Field(adding ? "0" : String.valueOf(existing.getGoals()));
        Theme.Field rating = new Theme.Field(adding ? "70" : String.valueOf(existing.getRating()), "1 - 99");
        Theme.Combo status = new Theme.Combo(Player.STATUSES);
        if (!adding) {
            pos.setSelectedItem(existing.getPosition());
            status.setSelectedItem(existing.getStatus());
        }

        boolean saved = FormDialog.show(this, adding ? "Add player" : "Edit player",
                adding ? "Register a new player in your squad." : "Update the details of " + existing.getName() + ".",
                adding ? "Add player" : "Save changes",
                new String[]{"Full name", "~Shirt number", "~Age", "~Position", "~Status", "~Goals scored", "~Rating (1-99)"},
                new JComponent[]{name, shirt, age, pos, status, goals, rating},
                () -> validate(adding, shirt, name, age, goals, rating));
        if (!saved) return;

        int n = parseInt(shirt.getText());
        String position = (String) pos.getSelectedItem();
        String st = (String) status.getSelectedItem();
        if (adding) {
            store.players().addPlayer(new Player(n, name.getText().trim(), position, parseInt(age.getText()),
                    parseInt(goals.getText()), parseInt(rating.getText()), st));
            app.changed();
            app.toast(name.getText().trim() + " added to the squad");
        } else {
            store.players().updatePlayer(n, name.getText().trim(), position, parseInt(age.getText()),
                    parseInt(goals.getText()), parseInt(rating.getText()), st);
            app.changed();
            app.toast("Player updated");
        }
    }

    private String validate(boolean adding, JTextField shirt, JTextField name, JTextField age,
                            JTextField goals, JTextField rating) {
        Integer n = parseInt(shirt.getText()), a = parseInt(age.getText()),
                g = parseInt(goals.getText()), r = parseInt(rating.getText());
        if (name.getText().trim().isEmpty()) return "Please enter the player's name.";
        if (n == null || a == null || g == null || r == null) return "Shirt number, age, goals and rating must be whole numbers.";
        if (n < 1 || n > 99) return "Shirt number must be between 1 and 99.";
        if (adding && store.players().searchPlayer(n) != null) return "Shirt number " + n + " is already taken.";
        if (a < 14 || a > 50) return "Age must be between 14 and 50.";
        if (g < 0) return "Goals cannot be negative.";
        if (r < 1 || r > 99) return "Rating must be between 1 and 99.";
        return null;
    }
}
