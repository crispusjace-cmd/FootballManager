import java.time.LocalDate;

/** One planned or completed training session. */
public class TrainingSession {

    public static final String[] TYPES = {"Fitness", "Tactical", "Technical", "Set Pieces", "Recovery", "Match Prep"};
    public static final String[] INTENSITIES = {"Low", "Medium", "High"};

    private final String type;
    private final LocalDate date;
    private final int minutes;
    private final String intensity;
    private final String notes;

    public TrainingSession(String type, LocalDate date, int minutes, String intensity, String notes) {
        this.type = type;
        this.date = date;
        this.minutes = minutes;
        this.intensity = intensity;
        this.notes = notes == null ? "" : notes;
    }

    public String getType() { return type; }
    public LocalDate getDate() { return date; }
    public int getMinutes() { return minutes; }
    public String getIntensity() { return intensity; }
    public String getNotes() { return notes; }
}
