public class PlayerTest {

    public static void main(String[] args) {

        // Create PlayerManager
        PlayerManager manager = new PlayerManager();

        // Create players
        Player p1 = new Player(10, "Crispus",
                "Midfielder", 21, 5);

        Player p2 = new Player(9, "John",
                "Forward", 24, 12);

        Player p3 = new Player(1, "James",
                "Goalkeeper", 25, 0);

        Player p4 = new Player(4, "David",
                "Defender", 23, 2);

        // Register players
        System.out.println("REGISTERING PLAYERS");

        manager.addPlayer(p1);
        manager.addPlayer(p2);
        manager.addPlayer(p3);
        manager.addPlayer(p4);

        // Display squad
        System.out.println("\nOUR SQUAD");

        manager.displayAllPlayers();

        // Total players
        System.out.println("\nTOTAL PLAYERS: "
                + manager.getTotalPlayers());

        // Count positions
        System.out.println("GOALKEEPERS: "
                + manager.getGoalkeeperCount());

        System.out.println("DEFENDERS: "
                + manager.getDefenderCount());

        System.out.println("MIDFIELDERS: "
                + manager.getMidfielderCount());

        System.out.println("FORWARDS: "
                + manager.getForwardCount());

        // Search player
        System.out.println("\nSEARCHING FOR PLAYER");

        Player found = manager.searchPlayer(10);

        if (found != null) {
            System.out.println("Found: " + found.getName());
        }

        // Update player
        System.out.println("\nUPDATING PLAYER");

        manager.updatePlayer(10, "Crispus",
                "Midfielder", 21, 6);

        // Display updated goals
        System.out.println("Updated goals: "
                + manager.searchPlayer(10).getGoals());

        // Remove player
        System.out.println("\nREMOVING PLAYER");

        manager.removePlayer(9);

        System.out.println("Remaining players: "
                + manager.getTotalPlayers());

    }
}