import java.awt.*;
import java.awt.geom.*;

/** Tiny vector icons drawn with Java2D, so they look sharp and never depend on fonts. */
public final class Icons {

    private Icons() {}

    public static void draw(String name, Graphics2D g0, float x, float y, float s, Color c) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.aa(g);
        g.setColor(c);
        g.setStroke(new BasicStroke(Math.max(1.6f, s * 0.085f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        switch (name) {
            case "dashboard": {
                float a = s * 0.36f, gap = s * 0.12f, o = (s - 2 * a - gap) / 2;
                for (int i = 0; i < 2; i++)
                    for (int j = 0; j < 2; j++)
                        g.draw(new RoundRectangle2D.Float(x + o + i * (a + gap), y + o + j * (a + gap), a, a, s * 0.1f, s * 0.1f));
                break;
            }
            case "squad":
                g.draw(new Ellipse2D.Float(x + s * .34f, y + s * .14f, s * .32f, s * .32f));
                g.draw(new Arc2D.Float(x + s * .16f, y + s * .54f, s * .68f, s * .62f, 0, 180, Arc2D.OPEN));
                break;
            case "tactics":
                g.draw(new RoundRectangle2D.Float(x + s * .14f, y + s * .1f, s * .72f, s * .8f, s * .1f, s * .1f));
                g.draw(new Line2D.Float(x + s * .14f, y + s * .5f, x + s * .86f, y + s * .5f));
                g.draw(new Ellipse2D.Float(x + s * .38f, y + s * .38f, s * .24f, s * .24f));
                break;
            case "match":
                g.draw(new RoundRectangle2D.Float(x + s * .12f, y + s * .2f, s * .76f, s * .68f, s * .12f, s * .12f));
                g.draw(new Line2D.Float(x + s * .12f, y + s * .42f, x + s * .88f, y + s * .42f));
                g.draw(new Line2D.Float(x + s * .32f, y + s * .1f, x + s * .32f, y + s * .28f));
                g.draw(new Line2D.Float(x + s * .68f, y + s * .1f, x + s * .68f, y + s * .28f));
                g.fill(new Ellipse2D.Float(x + s * .42f, y + s * .56f, s * .16f, s * .16f));
                break;
            case "training":
                g.draw(new Ellipse2D.Float(x + s * .14f, y + s * .22f, s * .72f, s * .72f));
                g.draw(new Line2D.Float(x + s * .5f, y + s * .58f, x + s * .5f, y + s * .4f));
                g.draw(new Line2D.Float(x + s * .5f, y + s * .58f, x + s * .64f, y + s * .66f));
                g.draw(new Line2D.Float(x + s * .4f, y + s * .1f, x + s * .6f, y + s * .1f));
                g.draw(new Line2D.Float(x + s * .5f, y + s * .1f, x + s * .5f, y + s * .22f));
                break;
            case "ball": {
                g.draw(new Ellipse2D.Float(x + s * .1f, y + s * .1f, s * .8f, s * .8f));
                Path2D p = new Path2D.Float();
                for (int i = 0; i < 5; i++) {
                    double a = -Math.PI / 2 + i * 2 * Math.PI / 5;
                    float px = (float) (x + s * .5 + Math.cos(a) * s * .2);
                    float py = (float) (y + s * .5 + Math.sin(a) * s * .2);
                    if (i == 0) p.moveTo(px, py); else p.lineTo(px, py);
                    float ox = (float) (x + s * .5 + Math.cos(a) * s * .4);
                    float oy = (float) (y + s * .5 + Math.sin(a) * s * .4);
                    g.draw(new Line2D.Float(px, py, ox, oy));
                }
                p.closePath();
                g.fill(p);
                break;
            }
            case "bolt": {
                Path2D p = new Path2D.Float();
                p.moveTo(x + s * .56f, y + s * .08f);
                p.lineTo(x + s * .22f, y + s * .56f);
                p.lineTo(x + s * .48f, y + s * .56f);
                p.lineTo(x + s * .42f, y + s * .92f);
                p.lineTo(x + s * .78f, y + s * .42f);
                p.lineTo(x + s * .52f, y + s * .42f);
                p.closePath();
                g.fill(p);
                break;
            }
            case "goal":
                g.draw(new RoundRectangle2D.Float(x + s * .1f, y + s * .22f, s * .8f, s * .56f, s * .06f, s * .06f));
                for (int i = 1; i < 4; i++)
                    g.draw(new Line2D.Float(x + s * (.1f + .2f * i), y + s * .22f, x + s * (.1f + .2f * i), y + s * .78f));
                g.draw(new Line2D.Float(x + s * .1f, y + s * .5f, x + s * .9f, y + s * .5f));
                break;
            default:
                break;
        }
        g.dispose();
    }
}
