import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Small summary card: caption, big number, small note and a tinted icon badge. */
public class StatCard extends Theme.Rounded {

    private final String icon;
    private final Color accent;
    private final JLabel value = Theme.label("0", 30, Font.BOLD, Theme.TEXT);
    private final JLabel note = Theme.label(" ", 12, Font.PLAIN, Theme.MUTED);

    /** icon: an Icons name, or "text:GK" to show letters instead. */
    public StatCard(String title, String icon, Color accent) {
        super(new BorderLayout(), Theme.CARD, Theme.BORDER, 22);
        this.icon = icon;
        this.accent = accent;
        setBorder(new EmptyBorder(18, 20, 18, 20));
        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        JLabel cap = Theme.caption(title);
        cap.setAlignmentX(LEFT_ALIGNMENT);
        value.setAlignmentX(LEFT_ALIGNMENT);
        note.setAlignmentX(LEFT_ALIGNMENT);
        left.add(cap);
        left.add(Box.createVerticalStrut(8));
        left.add(value);
        left.add(Box.createVerticalStrut(2));
        left.add(note);
        add(left, BorderLayout.CENTER);
        JPanel badge = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                Theme.aa(g2);
                g2.setColor(Theme.alpha(accent, 34));
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                if (StatCard.this.icon.startsWith("text:")) {
                    g2.setColor(accent);
                    g2.setFont(Theme.font(Font.BOLD, 13));
                    String t = StatCard.this.icon.substring(5);
                    FontMetrics fm = g2.getFontMetrics();
                    g2.drawString(t, (getWidth() - fm.stringWidth(t)) / 2, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                } else {
                    Icons.draw(StatCard.this.icon, g2, 10, 10, getWidth() - 20, accent);
                }
                g2.dispose();
            }
        };
        badge.setOpaque(false);
        badge.setPreferredSize(new Dimension(44, 44));
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.add(badge, BorderLayout.NORTH);
        add(wrap, BorderLayout.EAST);
    }

    public void set(String v, String sub) {
        value.setText(v);
        note.setText(sub);
    }
}
