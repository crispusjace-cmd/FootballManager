/**
 * A single player in the squad.
 * Stores the basic details plus a rating (1-99) and a fitness status.
 */
public class Player {

    public static final String[] POSITIONS = {"Goalkeeper", "Defender", "Midfielder", "Forward"};
    public static final String[] STATUSES = {"Available", "Injured", "Suspended"};

    private int shirtNumber;
    private String name;
    private String position;
    private int age;
    private int goals;
    private int rating;
    private String status;

    // Original constructor (still works, rating defaults to 70)
    public Player(int shirtNumber, String name, String position, int age, int goals) {
        this(shirtNumber, name, position, age, goals, 70, "Available");
    }

    public Player(int shirtNumber, String name, String position, int age,
                  int goals, int rating, String status) {
        this.shirtNumber = shirtNumber;
        this.name = name;
        this.position = position;
        this.age = age;
        this.goals = goals;
        this.rating = rating;
        this.status = status;
    }

    public int getShirtNumber() { return shirtNumber; }
    public String getName() { return name; }
    public String getPosition() { return position; }
    public int getAge() { return age; }
    public int getGoals() { return goals; }
    public int getRating() { return rating; }
    public String getStatus() { return status; }

    public void setName(String name) { this.name = name; }
    public void setPosition(String position) { this.position = position; }
    public void setAge(int age) { this.age = age; }
    public void setGoals(int goals) { this.goals = goals; }
    public void setRating(int rating) { this.rating = rating; }
    public void setStatus(String status) { this.status = status; }

    /** Short role code used on the pitch: GK, DF, MF or FW. */
    public String getRole() {
        if (position == null) return "MF";
        switch (position.toLowerCase()) {
            case "goalkeeper": return "GK";
            case "defender":   return "DF";
            case "forward":    return "FW";
            default:           return "MF";
        }
    }

    public boolean isAvailable() { return "Available".equals(status); }

    /** Surname (or the whole name if it is a single word) - used for pitch labels. */
    public String getShortName() {
        String n = name == null ? "" : name.trim();
        int i = n.lastIndexOf(' ');
        return i >= 0 ? n.substring(i + 1) : n;
    }

    public void displayPlayer() {
        System.out.println("Shirt Number: " + shirtNumber);
        System.out.println("Name: " + name);
        System.out.println("Position: " + position);
        System.out.println("Age: " + age);
        System.out.println("Goals: " + goals);
        System.out.println("Rating: " + rating);
        System.out.println("Status: " + status);
    }
}
