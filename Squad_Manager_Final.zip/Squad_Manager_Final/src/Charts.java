import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;

/** Small custom-drawn charts used on the dashboard and training page. */
public final class Charts {

    private Charts() {}

    /** Ring chart (e.g. squad availability). */
    public static class Donut extends JPanel {
        private int[] values = {0};
        private Color[] colors = {Theme.GREEN};
        private String centre = "", sub = "";

        public Donut() { setOpaque(false); setPreferredSize(new Dimension(170, 170)); }

        public void set(int[] values, Color[] colors, String centre, String sub) {
            this.values = values; this.colors = colors; this.centre = centre; this.sub = sub;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            int size = Math.min(getWidth(), getHeight()) - 10;
            int x = (getWidth() - size) / 2, y = (getHeight() - size) / 2;
            float thick = size * 0.12f;
            Rectangle2D.Float box = new Rectangle2D.Float(x + thick / 2, y + thick / 2, size - thick, size - thick);
            g.setStroke(new BasicStroke(thick, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND));
            g.setColor(Theme.alpha(Theme.MUTED, 40));
            g.draw(new Ellipse2D.Float(box.x, box.y, box.width, box.height));
            int total = 0;
            for (int v : values) total += v;
            if (total > 0) {
                float start = 90;
                for (int i = 0; i < values.length; i++) {
                    if (values[i] == 0) continue;
                    float sweep = -360f * values[i] / total;
                    float gap = values[i] == total ? 0 : 3f;
                    g.setColor(colors[i]);
                    g.draw(new Arc2D.Float(box.x, box.y, box.width, box.height, start - (sweep < 0 ? gap / 2 : 0), sweep + gap, Arc2D.OPEN));
                    start += sweep;
                }
            }
            g.setFont(Theme.font(Font.BOLD, size * 0.2f));
            g.setColor(Theme.TEXT);
            FontMetrics fm = g.getFontMetrics();
            g.drawString(centre, getWidth() / 2 - fm.stringWidth(centre) / 2, getHeight() / 2 + fm.getAscent() / 3);
            g.setFont(Theme.font(Font.PLAIN, 11));
            g.setColor(Theme.MUTED);
            fm = g.getFontMetrics();
            g.drawString(sub, getWidth() / 2 - fm.stringWidth(sub) / 2, getHeight() / 2 + size / 7 + 4);
            g.dispose();
        }
    }

    /** Minutes of training per day for the current week (Monday to Sunday). */
    public static class WeekChart extends JPanel {
        private List<TrainingSession> sessions = new java.util.ArrayList<>();

        public WeekChart() { setOpaque(false); setPreferredSize(new Dimension(300, 220)); }

        public void set(List<TrainingSession> s) { sessions = s; repaint(); }

        public static LocalDate weekStart() {
            LocalDate t = LocalDate.now();
            return t.minusDays(t.getDayOfWeek().getValue() - DayOfWeek.MONDAY.getValue());
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.aa(g);
            LocalDate start = weekStart(), today = LocalDate.now();
            int[] mins = new int[7];
            String[] level = new String[7];
            for (TrainingSession s : sessions) {
                long d = java.time.temporal.ChronoUnit.DAYS.between(start, s.getDate());
                if (d >= 0 && d < 7) {
                    mins[(int) d] += s.getMinutes();
                    if (level[(int) d] == null || "High".equals(s.getIntensity())) level[(int) d] = s.getIntensity();
                }
            }
            int max = 60;
            for (int m : mins) max = Math.max(max, m);
            max = ((max + 29) / 30) * 30;

            int left = 34, bottom = 28, top = 18;
            int w = getWidth() - left - 6, h = getHeight() - bottom - top;
            g.setFont(Theme.font(Font.PLAIN, 10.5f));
            FontMetrics fm = g.getFontMetrics();
            for (int i = 0; i <= 3; i++) {
                int yy = top + h - h * i / 3;
                g.setColor(Theme.alpha(Theme.MUTED, 38));
                g.drawLine(left, yy, left + w, yy);
                String lab = String.valueOf(max * i / 3);
                g.setColor(Theme.MUTED);
                g.drawString(lab, left - 8 - fm.stringWidth(lab), yy + fm.getAscent() / 2 - 1);
            }
            int slot = w / 7, bar = Math.min(34, slot - 14);
            for (int i = 0; i < 7; i++) {
                int cx = left + slot * i + slot / 2;
                int bh = (int) (h * (mins[i] / (double) max));
                Color col = "High".equals(level[i]) ? Theme.RED : "Medium".equals(level[i]) ? Theme.GOLD : Theme.GREEN;
                if (mins[i] > 0) {
                    g.setPaint(new GradientPaint(0, top + h - bh, col, 0, top + h, Theme.alpha(col, 110)));
                    g.fill(new RoundRectangle2D.Float(cx - bar / 2f, top + h - bh, bar, bh, 10, 10));
                    String t = String.valueOf(mins[i]);
                    g.setFont(Theme.font(Font.BOLD, 11));
                    g.setColor(Theme.TEXT);
                    g.drawString(t, cx - g.getFontMetrics().stringWidth(t) / 2, top + h - bh - 6);
                } else {
                    g.setColor(Theme.alpha(Theme.MUTED, 40));
                    g.fill(new RoundRectangle2D.Float(cx - bar / 2f, top + h - 4, bar, 4, 4, 4));
                }
                LocalDate day = start.plusDays(i);
                boolean isToday = day.equals(today);
                g.setFont(Theme.font(isToday ? Font.BOLD : Font.PLAIN, 11.5f));
                g.setColor(isToday ? Theme.GREEN : Theme.MUTED);
                String dn = day.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
                g.drawString(dn, cx - g.getFontMetrics().stringWidth(dn) / 2, getHeight() - 8);
            }
            g.dispose();
        }
    }
}
