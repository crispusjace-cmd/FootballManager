import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;

/**
 * Draws the pitch with the starting XI. On the Tactics page it is interactive:
 * click a position to pick a player. On the dashboard it is read-only.
 */
public class PitchPanel extends JPanel {

    private final DataStore store;
    private final boolean interactive;
    private Runnable onChange = () -> { };
    private int hover = -1;
    private Point[] centers = new Point[11];
    private int radius = 20;

    public PitchPanel(DataStore store, boolean interactive) {
        this.store = store;
        this.interactive = interactive;
        setOpaque(false);
        setPreferredSize(new Dimension(380, 540));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        MouseAdapter m = new MouseAdapter() {
            @Override public void mouseMoved(MouseEvent e) {
                int h = slotAt(e.getPoint());
                if (h != hover) { hover = h; repaint(); }
            }
            @Override public void mouseExited(MouseEvent e) { hover = -1; repaint(); }
            @Override public void mouseClicked(MouseEvent e) {
                int s = slotAt(e.getPoint());
                if (interactive && s >= 0) choosePlayer(s, e.getPoint());
                else if (!interactive) onChange.run();
            }
        };
        addMouseListener(m);
        addMouseMotionListener(m);
    }

    /** Interactive pitch: called after a player is picked. Read-only pitch: called when clicked. */
    public void setOnChange(Runnable r) { onChange = r; }

    private int slotAt(Point p) {
        for (int i = 0; i < 11; i++) {
            if (centers[i] != null && centers[i].distance(p) <= radius + 8) return i;
        }
        return -1;
    }

    // ------------------------------------------------------------ player picker
    private void choosePlayer(int slot, Point at) {
        Formations.Slot[] slots = Formations.get(store.getFormation());
        String role = slots[slot].role;
        JPopupMenu menu = new JPopupMenu();
        JMenuItem header = new JMenuItem("Choose " + role + " for this position");
        header.setEnabled(false);
        menu.add(header);

        List<Player> same = new ArrayList<>(), other = new ArrayList<>();
        for (Player p : store.players().getPlayers()) {
            if (store.isStarter(p.getShirtNumber()) && p != store.lineupPlayer(slot)) continue;
            if (p == store.lineupPlayer(slot)) continue;
            (p.getRole().equals(role) ? same : other).add(p);
        }
        Comparator<Player> best = Comparator.comparingInt(Player::getRating).reversed();
        same.sort(best);
        other.sort(best);

        for (Player p : same) menu.add(item(p, slot));
        if (!other.isEmpty()) {
            menu.addSeparator();
            JMenuItem sub = new JMenuItem("Other positions");
            sub.setEnabled(false);
            menu.add(sub);
            for (int i = 0; i < Math.min(6, other.size()); i++) menu.add(item(other.get(i), slot));
        }
        if (store.lineupPlayer(slot) != null) {
            menu.addSeparator();
            JMenuItem clear = new JMenuItem("Remove " + store.lineupPlayer(slot).getShortName() + " from XI");
            clear.addActionListener(e -> { store.setSlot(slot, 0); onChange.run(); repaint(); });
            menu.add(clear);
        }
        menu.show(this, at.x + 8, at.y + 8);
    }

    private JMenuItem item(Player p, int slot) {
        String text = "#" + p.getShirtNumber() + "   " + p.getName() + "   ·   " + p.getRole() + "   ·   " + p.getRating();
        if (!p.isAvailable()) text += "   (" + p.getStatus() + ")";
        JMenuItem it = new JMenuItem(text);
        it.setEnabled(p.isAvailable());
        it.addActionListener(e -> { store.setSlot(slot, p.getShirtNumber()); onChange.run(); repaint(); });
        return it;
    }

    // ------------------------------------------------------------ drawing
    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.aa(g);
        int w = getWidth(), h = getHeight();
        int x = 0, y = 0, pw = w - 1, ph = h - 1;
        Shape clip = new RoundRectangle2D.Float(x, y, pw, ph, 22, 22);
        g.setClip(clip);

        int bands = 12;
        for (int i = 0; i < bands; i++) {
            g.setColor(i % 2 == 0 ? new Color(20, 124, 74) : new Color(17, 110, 66));
            int y1 = y + i * ph / bands, y2 = y + (i + 1) * ph / bands;
            g.fillRect(x, y1, pw, y2 - y1 + 1);
        }
        g.setPaint(new GradientPaint(0, 0, new Color(255, 255, 255, 26), 0, h, new Color(0, 0, 0, 70)));
        g.fillRect(0, 0, w, h);

        int m = Math.max(12, w / 24);
        int fx = x + m, fy = y + m, fw = pw - 2 * m, fh = ph - 2 * m;
        g.setColor(new Color(255, 255, 255, 150));
        g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawRect(fx, fy, fw, fh);
        g.drawLine(fx, fy + fh / 2, fx + fw, fy + fh / 2);
        int cr = (int) (fw * 0.14);
        g.drawOval(fx + fw / 2 - cr, fy + fh / 2 - cr, cr * 2, cr * 2);
        g.fillOval(fx + fw / 2 - 3, fy + fh / 2 - 3, 6, 6);
        int boxW = (int) (fw * 0.58), boxH = (int) (fh * 0.16);
        int sixW = (int) (fw * 0.28), sixH = (int) (fh * 0.065);
        g.drawRect(fx + (fw - boxW) / 2, fy, boxW, boxH);
        g.drawRect(fx + (fw - boxW) / 2, fy + fh - boxH, boxW, boxH);
        g.drawRect(fx + (fw - sixW) / 2, fy, sixW, sixH);
        g.drawRect(fx + (fw - sixW) / 2, fy + fh - sixH, sixW, sixH);
        int ar = (int) (fw * 0.12), spot = (int) (fh * 0.115);
        g.draw(new Arc2D.Float(fx + fw / 2f - ar, fy + spot - ar, ar * 2, ar * 2, 220, 100, Arc2D.OPEN));
        g.draw(new Arc2D.Float(fx + fw / 2f - ar, fy + fh - spot - ar, ar * 2, ar * 2, 40, 100, Arc2D.OPEN));
        g.setClip(null);

        // players
        radius = Math.max(15, Math.min(24, Math.min(w, h) / 20));
        Formations.Slot[] slots = Formations.get(store.getFormation());
        for (int i = 0; i < 11; i++) {
            int cx = fx + (int) (fw * slots[i].x);
            int cy = fy + (int) (fh * slots[i].y);
            centers[i] = new Point(cx, cy);
            drawSlot(g, i, cx, cy, slots[i].role, store.lineupPlayer(i));
        }
        g.dispose();
    }

    private void drawSlot(Graphics2D g, int index, int cx, int cy, String role, Player p) {
        int r = radius;
        Color ring = Theme.roleColor(role);
        g.setColor(new Color(0, 0, 0, 70));
        g.fillOval(cx - r + 1, cy - r + 4, r * 2, r * 2);
        if (p == null) {
            g.setColor(new Color(0, 0, 0, 90));
            g.fillOval(cx - r, cy - r, r * 2, r * 2);
            g.setColor(index == hover ? Color.WHITE : new Color(255, 255, 255, 190));
            g.setStroke(new BasicStroke(2f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, new float[]{4f, 4f}, 0f));
            g.drawOval(cx - r, cy - r, r * 2, r * 2);
            g.setFont(Theme.font(Font.BOLD, 11));
            g.setColor(Color.WHITE);
            FontMetrics fm = g.getFontMetrics();
            g.drawString(role, cx - fm.stringWidth(role) / 2, cy + (fm.getAscent() - fm.getDescent()) / 2);
            return;
        }
        g.setColor(new Color(8, 18, 34));
        g.fillOval(cx - r, cy - r, r * 2, r * 2);
        g.setColor(index == hover ? Color.WHITE : ring);
        g.setStroke(new BasicStroke(3f));
        g.drawOval(cx - r, cy - r, r * 2, r * 2);
        String num = String.valueOf(p.getShirtNumber());
        g.setFont(Theme.font(Font.BOLD, r * 0.82f));
        FontMetrics fm = g.getFontMetrics();
        g.setColor(Color.WHITE);
        g.drawString(num, cx - fm.stringWidth(num) / 2, cy + (fm.getAscent() - fm.getDescent()) / 2);

        // name tag
        String name = p.getShortName();
        if (name.length() > 11) name = name.substring(0, 10) + ".";
        g.setFont(Theme.font(Font.BOLD, 11.5f));
        fm = g.getFontMetrics();
        int tw = fm.stringWidth(name) + 14, th = 20;
        int tx = cx - tw / 2, ty = cy + r + 6;
        g.setColor(new Color(4, 12, 24, 190));
        g.fillRoundRect(tx, ty, tw, th, th, th);
        g.setColor(Color.WHITE);
        g.drawString(name, tx + 7, ty + (th + fm.getAscent() - fm.getDescent()) / 2);
    }
}
