import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;

/**
 * Handles coach accounts. Passwords are NEVER stored as plain text:
 * each one is salted and hashed with PBKDF2 (a standard, slow hash that
 * makes password guessing very hard). Accounts live in their own file,
 * so "Clear all" in the app never deletes them.
 */
public class AuthService {

    private static final Path FILE = Paths.get(System.getProperty("user.home"), ".football_manager", "users.txt");
    private static final int ITERATIONS = 120_000;

    // username (lower case) -> {display name, salt (base64), hash (base64)}
    private final Map<String, String[]> users = new LinkedHashMap<>();

    public AuthService() { load(); }

    public boolean hasUsers() { return !users.isEmpty(); }

    /** Returns an error message, or null if the account was created. */
    public String register(String username, String password) {
        String name = username == null ? "" : username.trim();
        if (!name.matches("[A-Za-z0-9_]{3,20}")) return "Username must be 3-20 letters, numbers or underscores.";
        if (password == null || password.length() < 6) return "Password must be at least 6 characters.";
        if (users.containsKey(name.toLowerCase())) return "That username is already taken.";
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        String hash = Base64.getEncoder().encodeToString(hash(password.toCharArray(), salt));
        users.put(name.toLowerCase(), new String[]{name, Base64.getEncoder().encodeToString(salt), hash});
        save();
        return null;
    }

    /** Returns the display name if the login is correct, otherwise null. */
    public String authenticate(String username, String password) {
        if (username == null || password == null) return null;
        String[] u = users.get(username.trim().toLowerCase());
        if (u == null) return null;
        byte[] salt = Base64.getDecoder().decode(u[1]);
        byte[] expected = Base64.getDecoder().decode(u[2]);
        byte[] actual = hash(password.toCharArray(), salt);
        return MessageDigest.isEqual(expected, actual) ? u[0] : null;
    }

    private static byte[] hash(char[] password, byte[] salt) {
        try {
            SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            return f.generateSecret(new PBEKeySpec(password, salt, ITERATIONS, 256)).getEncoded();
        } catch (Exception e) {
            throw new IllegalStateException("Password hashing is not available", e);
        }
    }

    private void load() {
        if (!Files.exists(FILE)) return;
        try {
            for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
                String[] f = line.split("\t");
                if (f.length == 3) users.put(f[0].toLowerCase(), new String[]{f[0], f[1], f[2]});
            }
        } catch (IOException e) {
            System.err.println("Could not read accounts: " + e);
        }
    }

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (String[] u : users.values()) sb.append(u[0]).append('\t').append(u[1]).append('\t').append(u[2]).append('\n');
        try {
            Files.createDirectories(FILE.getParent());
            Files.write(FILE, sb.toString().getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("Could not save accounts: " + e);
        }
    }
}
