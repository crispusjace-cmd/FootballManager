import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

/**
 * Everything the app remembers: team name, formation, starting XI, players,
 * matches and training sessions. Saved to a plain text file in the user's
 * home folder so nothing is lost when the program closes.
 */
public class DataStore {

    private static final Path FILE =
            Paths.get(System.getProperty("user.home"), ".football_manager", "data.txt");

    private String teamName = "Northside United FC";
    private String formation = "4-3-3";
    private int[] lineup = new int[11];             // shirt number per pitch slot, 0 = empty
    private final PlayerManager players = new PlayerManager();
    private final List<Match> matches = new ArrayList<>();
    private final List<TrainingSession> sessions = new ArrayList<>();

    // ---------------------------------------------------------------- load / save

    public static DataStore load() {
        DataStore store = new DataStore();
        if (Files.exists(FILE)) {
            try {
                store.read();
                return store;
            } catch (Exception e) {
                System.err.println("Could not read save file, starting with demo data: " + e);
                store = new DataStore();
            }
        }
        store.seedDemo();
        store.save();
        return store;
    }

    public void save() {
        StringBuilder sb = new StringBuilder();
        sb.append("TEAM\t").append(clean(teamName)).append('\n');
        sb.append("FORMATION\t").append(formation).append('\n');
        StringBuilder l = new StringBuilder();
        for (int i = 0; i < lineup.length; i++) l.append(i == 0 ? "" : ",").append(lineup[i]);
        sb.append("LINEUP\t").append(l).append('\n');

        for (Player p : players.getPlayers()) {
            sb.append("PLAYER\t").append(p.getShirtNumber()).append('\t').append(clean(p.getName()))
              .append('\t').append(p.getPosition()).append('\t').append(p.getAge())
              .append('\t').append(p.getGoals()).append('\t').append(p.getRating())
              .append('\t').append(p.getStatus()).append('\n');
        }
        for (Match m : matches) {
            StringBuilder sc = new StringBuilder();
            for (int i = 0; i < m.getScorers().size(); i++) sc.append(i == 0 ? "" : ",").append(m.getScorers().get(i));
            sb.append("MATCH\t").append(clean(m.getOpponent())).append('\t').append(m.getDate())
              .append('\t').append(m.getVenue()).append('\t').append(m.getGoalsFor())
              .append('\t').append(m.getGoalsAgainst()).append('\t').append(m.isPlayed())
              .append('\t').append(sc).append('\n');
        }
        for (TrainingSession t : sessions) {
            sb.append("TRAIN\t").append(t.getType()).append('\t').append(t.getDate())
              .append('\t').append(t.getMinutes()).append('\t').append(t.getIntensity())
              .append('\t').append(clean(t.getNotes())).append('\n');
        }
        try {
            Files.createDirectories(FILE.getParent());
            Files.write(FILE, sb.toString().getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("Could not save data: " + e);
        }
    }

    private void read() throws IOException {
        for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
            String[] f = line.split("\t", -1);
            switch (f[0]) {
                case "TEAM": teamName = f[1]; break;
                case "FORMATION": formation = f[1]; break;
                case "LINEUP": {
                    String[] parts = f[1].split(",");
                    for (int i = 0; i < 11 && i < parts.length; i++) lineup[i] = Integer.parseInt(parts[i].trim());
                    break;
                }
                case "PLAYER":
                    players.addPlayer(new Player(Integer.parseInt(f[1]), f[2], f[3], Integer.parseInt(f[4]),
                            Integer.parseInt(f[5]), Integer.parseInt(f[6]), f[7]));
                    break;
                case "MATCH": {
                    Match m = new Match(f[1], LocalDate.parse(f[2]), f[3]);
                    if (Boolean.parseBoolean(f[6])) {
                        List<Integer> sc = new ArrayList<>();
                        if (f.length > 7 && !f[7].isEmpty())
                            for (String s : f[7].split(",")) sc.add(Integer.parseInt(s.trim()));
                        m.setResult(Integer.parseInt(f[4]), Integer.parseInt(f[5]), sc);
                    }
                    matches.add(m);
                    break;
                }
                case "TRAIN":
                    sessions.add(new TrainingSession(f[1], LocalDate.parse(f[2]), Integer.parseInt(f[3]), f[4],
                            f.length > 5 ? f[5] : ""));
                    break;
                default: break;
            }
        }
        cleanLineup();
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
    }

    // ---------------------------------------------------------------- demo / reset

    public void clearAll() {
        players.clear();
        matches.clear();
        sessions.clear();
        lineup = new int[11];
        formation = "4-3-3";
    }

    public void seedDemo() {
        clearAll();
        Object[][] squad = {
            {1,  "Daniel Okello",       "Goalkeeper", 27, 0, 78, "Available"},
            {13, "Brian Mugisha",       "Goalkeeper", 22, 0, 69, "Available"},
            {30, "Isaac Lutaaya",       "Goalkeeper", 31, 0, 66, "Available"},
            {2,  "Moses Kato",          "Defender",   26, 1, 74, "Available"},
            {3,  "Peter Ssewanyana",    "Defender",   24, 2, 76, "Available"},
            {4,  "David Wasswa",        "Defender",   29, 3, 79, "Available"},
            {5,  "Joel Byaruhanga",     "Defender",   23, 1, 72, "Available"},
            {12, "Titus Mbabazi",       "Defender",   28, 0, 71, "Injured"},
            {15, "Samuel Opio",         "Defender",   21, 0, 68, "Available"},
            {16, "Ivan Kiggundu",       "Defender",   25, 0, 70, "Available"},
            {6,  "Henry Kizza",         "Midfielder", 28, 4, 77, "Available"},
            {8,  "Collins Ochieng",     "Midfielder", 25, 5, 80, "Available"},
            {10, "Crispus Mwesigwa",    "Midfielder", 21, 6, 82, "Available"},
            {14, "Allan Tumusiime",     "Midfielder", 23, 2, 73, "Available"},
            {17, "Nathan Ssebunya",     "Midfielder", 20, 1, 70, "Available"},
            {20, "Patrick Odongo",      "Midfielder", 27, 3, 75, "Suspended"},
            {7,  "Emmanuel Mukasa",     "Forward",    24, 9, 81, "Available"},
            {9,  "John Ekiru",          "Forward",    24, 12, 83, "Available"},
            {11, "Ronald Atwine",       "Forward",    22, 7, 77, "Available"},
            {18, "Kevin Ouma",          "Forward",    19, 2, 69, "Available"},
            {19, "Jackson Wanyama",     "Forward",    26, 5, 74, "Available"},
        };
        for (Object[] r : squad) {
            players.addPlayer(new Player((Integer) r[0], (String) r[1], (String) r[2],
                    (Integer) r[3], (Integer) r[4], (Integer) r[5], (String) r[6]));
        }
        autoPick();

        LocalDate today = LocalDate.now();
        Match m1 = new Match("Kampala City FC", today.minusDays(21), "Home");
        m1.setResult(2, 1, Arrays.asList(9, 10));
        Match m2 = new Match("Entebbe Rovers", today.minusDays(14), "Away");
        m2.setResult(1, 1, Arrays.asList(7));
        Match m3 = new Match("Jinja Lions", today.minusDays(7), "Home");
        m3.setResult(0, 2, new ArrayList<Integer>());
        matches.addAll(Arrays.asList(m1, m2, m3,
                new Match("Mbarara Stars", today.plusDays(3), "Away"),
                new Match("Gulu Warriors", today.plusDays(10), "Home"),
                new Match("Masaka United", today.plusDays(17), "Away")));

        sessions.add(new TrainingSession("Tactical", today.minusDays(2), 75, "Medium", "Pressing triggers"));
        sessions.add(new TrainingSession("Recovery", today.minusDays(1), 45, "Low", "Pool and stretching"));
        sessions.add(new TrainingSession("Fitness", today.plusDays(1), 90, "High", "Interval running"));
        sessions.add(new TrainingSession("Set Pieces", today.plusDays(2), 60, "Medium", "Corners and free kicks"));
        sessions.add(new TrainingSession("Match Prep", today.plusDays(3), 50, "Low", "Walkthrough vs Mbarara"));
    }

    // ---------------------------------------------------------------- basic access

    public PlayerManager players() { return players; }
    public List<Match> matches() { return matches; }
    public List<TrainingSession> sessions() { return sessions; }
    public String getTeamName() { return teamName; }
    public void setTeamName(String n) { teamName = n; }
    public String getFormation() { return formation; }
    public int[] getLineup() { return lineup; }

    // ---------------------------------------------------------------- lineup

    /** Change formation and keep as many starters as possible in matching roles. */
    public void setFormation(String name) {
        Formations.Slot[] slots = Formations.get(name);
        List<Player> starters = new ArrayList<>();
        for (int s : lineup) {
            Player p = players.searchPlayer(s);
            if (p != null) starters.add(p);
        }
        int[] next = new int[11];
        for (int i = 0; i < 11; i++) {
            for (Iterator<Player> it = starters.iterator(); it.hasNext(); ) {
                Player p = it.next();
                if (p.getRole().equals(slots[i].role)) {
                    next[i] = p.getShirtNumber();
                    it.remove();
                    break;
                }
            }
        }
        formation = name;
        lineup = next;
    }

    public Player lineupPlayer(int slot) { return players.searchPlayer(lineup[slot]); }

    public boolean isStarter(int shirt) {
        for (int s : lineup) if (s == shirt && shirt != 0) return true;
        return false;
    }

    public void setSlot(int slot, int shirt) {
        for (int i = 0; i < lineup.length; i++) if (shirt != 0 && lineup[i] == shirt) lineup[i] = 0;
        lineup[slot] = shirt;
    }

    public void clearLineup() { lineup = new int[11]; }

    public int lineupCount() {
        int n = 0;
        for (int i = 0; i < 11; i++) if (lineupPlayer(i) != null) n++;
        return n;
    }

    /** Remove starters who were deleted from the squad. */
    public void cleanLineup() {
        for (int i = 0; i < 11; i++) if (players.searchPlayer(lineup[i]) == null) lineup[i] = 0;
    }

    /** Pick the best available player for every slot (matching role first). */
    public void autoPick() {
        Formations.Slot[] slots = Formations.get(formation);
        int[] result = new int[11];
        Set<Integer> used = new HashSet<>();
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < 11; i++) {
                if (result[i] != 0) continue;
                Player best = null;
                for (Player p : players.getPlayers()) {
                    if (!p.isAvailable() || used.contains(p.getShirtNumber())) continue;
                    if (pass == 0 && !p.getRole().equals(slots[i].role)) continue;
                    if (best == null || p.getRating() > best.getRating()) best = p;
                }
                if (best != null) {
                    result[i] = best.getShirtNumber();
                    used.add(best.getShirtNumber());
                }
            }
        }
        lineup = result;
    }

    public double lineupAverageRating() {
        int n = 0, sum = 0;
        for (int i = 0; i < 11; i++) {
            Player p = lineupPlayer(i);
            if (p != null) { n++; sum += p.getRating(); }
        }
        return n == 0 ? 0 : (double) sum / n;
    }

    // ---------------------------------------------------------------- matches

    public List<Match> upcoming() {
        List<Match> list = new ArrayList<>();
        for (Match m : matches) if (!m.isPlayed()) list.add(m);
        list.sort(Comparator.comparing(Match::getDate));
        return list;
    }

    public List<Match> results() {
        List<Match> list = new ArrayList<>();
        for (Match m : matches) if (m.isPlayed()) list.add(m);
        list.sort(Comparator.comparing(Match::getDate).reversed());
        return list;
    }

    /** {wins, draws, losses, goalsFor, goalsAgainst} */
    public int[] record() {
        int w = 0, d = 0, l = 0, gf = 0, ga = 0;
        for (Match m : matches) {
            if (!m.isPlayed()) continue;
            gf += m.getGoalsFor();
            ga += m.getGoalsAgainst();
            switch (m.getResultLetter()) {
                case "W": w++; break;
                case "D": d++; break;
                default: l++;
            }
        }
        return new int[]{w, d, l, gf, ga};
    }

    public void recordResult(Match m, int gf, int ga, List<Integer> scorers) {
        m.setResult(gf, ga, scorers);
        for (int s : scorers) {
            Player p = players.searchPlayer(s);
            if (p != null) p.setGoals(p.getGoals() + 1);
        }
    }

    public void deleteMatch(Match m) {
        if (m.isPlayed()) {
            for (int s : m.getScorers()) {
                Player p = players.searchPlayer(s);
                if (p != null) p.setGoals(Math.max(0, p.getGoals() - 1));
            }
        }
        matches.remove(m);
    }

    // ---------------------------------------------------------------- training

    public List<TrainingSession> sortedSessions() {
        List<TrainingSession> list = new ArrayList<>(sessions);
        list.sort(Comparator.comparing(TrainingSession::getDate));
        return list;
    }
}
