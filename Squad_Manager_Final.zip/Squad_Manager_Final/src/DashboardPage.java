import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.List;

/** The home screen: a quick picture of the whole team. */
public class DashboardPage extends Page {

    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("EEE d MMM", Locale.ENGLISH);

    private final JLabel title = Theme.label("", 30, Font.BOLD, Theme.TEXT);
    private final StatCard squadCard = new StatCard("Squad", "squad", Theme.GREEN);
    private final StatCard formationCard = new StatCard("Formation", "tactics", Theme.BLUE);
    private final StatCard recordCard = new StatCard("Season record", "match", Theme.GOLD);
    private final StatCard trainingCard = new StatCard("Training this week", "training", new Color(255, 112, 112));
    private final PitchPanel pitch;
    private final JLabel pitchTag = Theme.label("", 12, Font.BOLD, Theme.GREEN);
    private final JPanel nextMatchBody = box(new BorderLayout());
    private final Charts.WeekChart weekChart = new Charts.WeekChart();
    private final JLabel trainingLine = Theme.label(" ", 13, Font.PLAIN, Theme.MUTED);
    private final Charts.Donut donut = new Charts.Donut();
    private final JPanel legend = box(new GridLayout(3, 1, 0, 10));
    private final Theme.VList scorers = new Theme.VList();

    public DashboardPage(AppShell app) {
        super(app);
        pitch = new PitchPanel(store, false);
        pitch.setOnChange(() -> app.navigate("Tactics"));

        // ---- header
        JPanel text = box(null);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        title.setAlignmentX(LEFT_ALIGNMENT);
        JLabel sub = Theme.label(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH))
                + "  ·  Your coaching hub", 14, Font.PLAIN, Theme.MUTED);
        sub.setAlignmentX(LEFT_ALIGNMENT);
        text.add(title);
        text.add(Box.createVerticalStrut(4));
        text.add(sub);
        Theme.Btn rename = Theme.button("Rename team", Theme.Kind.SECONDARY);
        rename.addActionListener(e -> renameTeam());
        Theme.Btn lineup = Theme.button("Set lineup", Theme.Kind.PRIMARY);
        lineup.addActionListener(e -> app.navigate("Tactics"));
        JPanel actions = box(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actions.add(rename);
        actions.add(lineup);
        JPanel head = box(new BorderLayout());
        head.add(text, BorderLayout.WEST);
        head.add(actions, BorderLayout.EAST);
        add(head, BorderLayout.NORTH);

        // ---- content grid
        JPanel grid = box(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;

        JPanel stats = box(new GridLayout(1, 4, 16, 0));
        stats.add(squadCard);
        stats.add(formationCard);
        stats.add(recordCard);
        stats.add(trainingCard);
        c.gridx = 0; c.gridy = 0; c.gridwidth = 3; c.weightx = 1; c.weighty = 0;
        c.insets = new Insets(0, 0, 16, 0);
        grid.add(stats, c);

        Theme.Card pitchCardPanel = new Theme.Card("Starting XI", pitchTag);
        pitchCardPanel.body.add(pitch, BorderLayout.CENTER);
        c.gridy = 1; c.gridwidth = 1; c.weightx = 0.38; c.weighty = 1; c.insets = new Insets(0, 0, 0, 16);
        grid.add(pitchCardPanel, c);

        Theme.Card next = new Theme.Card("Next match");
        next.body.add(nextMatchBody, BorderLayout.CENTER);
        Theme.Card training = new Theme.Card("Weekly training load");
        JPanel tb = box(new BorderLayout(0, 8));
        tb.add(trainingLine, BorderLayout.NORTH);
        weekChart.setPreferredSize(new Dimension(280, 170));
        tb.add(weekChart, BorderLayout.CENTER);
        training.body.add(tb, BorderLayout.CENTER);
        JPanel mid = box(new GridBagLayout());
        GridBagConstraints m = new GridBagConstraints();
        m.fill = GridBagConstraints.BOTH; m.weightx = 1; m.gridx = 0;
        m.gridy = 0; m.weighty = 0.46; m.insets = new Insets(0, 0, 16, 0);
        mid.add(next, m);
        m.gridy = 1; m.weighty = 0.54; m.insets = new Insets(0, 0, 0, 0);
        mid.add(training, m);
        c.gridx = 1; c.weightx = 0.32; c.insets = new Insets(0, 0, 0, 16);
        grid.add(mid, c);

        Theme.Card avail = new Theme.Card("Squad availability");
        JPanel ab = box(new BorderLayout(18, 0));
        ab.add(donut, BorderLayout.WEST);
        JPanel lg = box(new GridBagLayout());
        lg.add(legend);
        ab.add(lg, BorderLayout.CENTER);
        avail.body.add(ab, BorderLayout.CENTER);
        Theme.Card top = new Theme.Card("Top scorers");
        top.body.add(scorers, BorderLayout.NORTH);
        JPanel right = box(new GridBagLayout());
        GridBagConstraints r = new GridBagConstraints();
        r.fill = GridBagConstraints.BOTH; r.weightx = 1; r.gridx = 0;
        r.gridy = 0; r.weighty = 0.40; r.insets = new Insets(0, 0, 16, 0);
        right.add(avail, r);
        r.gridy = 1; r.weighty = 0.60; r.insets = new Insets(0, 0, 0, 0);
        right.add(top, r);
        c.gridx = 2; c.weightx = 0.30; c.insets = new Insets(0, 0, 0, 0);
        grid.add(right, c);

        add(grid, BorderLayout.CENTER);
    }

    private void renameTeam() {
        Theme.Field f = new Theme.Field(store.getTeamName(), "Team name");
        boolean ok = FormDialog.show(this, "Rename team", "This name appears across the app.", "Save",
                new String[]{"Team name"}, new JComponent[]{f},
                () -> f.getText().trim().isEmpty() ? "Please enter a name." : null);
        if (ok) {
            store.setTeamName(f.getText().trim());
            app.changed();
            app.toast("Team renamed");
        }
    }

    @Override
    public void refresh() {
        PlayerManager pm = store.players();
        title.setText(store.getTeamName());
        squadCard.set(String.valueOf(pm.getTotalPlayers()), "avg age " + String.format("%.1f", pm.getAverageAge()));
        formationCard.set(store.getFormation(), store.lineupCount() + "/11 starters set");
        int[] rec = store.record();
        int played = rec[0] + rec[1] + rec[2];
        recordCard.set(rec[0] + "-" + rec[1] + "-" + rec[2], played == 0 ? "no matches played yet" : played + " played  ·  " + rec[3] + ":" + rec[4] + " goals");
        pitchTag.setText(store.getFormation() + "  ·  avg " + String.format("%.0f", store.lineupAverageRating()));

        // training
        LocalDate start = Charts.WeekChart.weekStart(), end = start.plusDays(6);
        int mins = 0, count = 0;
        for (TrainingSession s : store.sessions()) {
            if (!s.getDate().isBefore(start) && !s.getDate().isAfter(end)) { mins += s.getMinutes(); count++; }
        }
        trainingCard.set(String.valueOf(count), mins + " minutes planned");
        trainingLine.setText(count == 0 ? "No sessions planned this week." : count + " sessions  ·  " + mins + " minutes in total");
        weekChart.set(store.sessions());

        // next match + form
        nextMatchBody.removeAll();
        nextMatchBody.add(buildNextMatch(), BorderLayout.CENTER);

        // availability
        int av = pm.getCountByStatus("Available"), inj = pm.getCountByStatus("Injured"), sus = pm.getCountByStatus("Suspended");
        donut.set(new int[]{av, inj, sus}, new Color[]{Theme.GREEN, Theme.RED, Theme.GOLD},
                av + "/" + pm.getTotalPlayers(), "available");
        legend.removeAll();
        legend.add(legendRow("Available", av, Theme.GREEN));
        legend.add(legendRow("Injured", inj, Theme.RED));
        legend.add(legendRow("Suspended", sus, Theme.GOLD));

        // top scorers
        scorers.removeAll();
        List<Player> list = pm.getPlayers();
        list.sort(Comparator.comparingInt(Player::getGoals).reversed());
        int shown = 0;
        int best = list.isEmpty() ? 1 : Math.max(1, list.get(0).getGoals());
        for (Player p : list) {
            if (p.getGoals() == 0 || shown == 5) break;
            scorers.addRow(scorerRow(++shown, p, best));
        }
        if (shown == 0) scorers.add(Theme.label("No goals recorded yet.", 13, Font.PLAIN, Theme.MUTED));
        revalidate();
        repaint();
    }

    private JComponent legendRow(String name, int n, Color c) {
        JPanel p = box(new BorderLayout(10, 0));
        JComponent dot = new JComponent() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                Theme.aa(g2);
                g2.setColor(c);
                g2.fillOval(0, 4, 10, 10);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(10, 18); }
        };
        p.add(dot, BorderLayout.WEST);
        p.add(Theme.label(name, 13, Font.PLAIN, Theme.MUTED), BorderLayout.CENTER);
        p.add(Theme.label(String.valueOf(n), 15, Font.BOLD, Theme.TEXT), BorderLayout.EAST);
        return p;
    }

    private JComponent scorerRow(int rank, Player p, int best) {
        Theme.Rounded row = new Theme.Rounded(new BorderLayout(12, 0), Theme.CARD_ALT, null, 14);
        row.setBorder(new EmptyBorder(9, 12, 9, 14));
        JLabel rk = Theme.label(String.valueOf(rank), 13, Font.BOLD, rank == 1 ? Theme.GOLD : Theme.MUTED);
        rk.setPreferredSize(new Dimension(14, 20));
        JPanel mid = box(new GridLayout(2, 1, 0, 1));
        mid.add(Theme.label(p.getName(), 13.5f, Font.BOLD, Theme.TEXT));
        mid.add(Theme.label(p.getPosition(), 11.5f, Font.PLAIN, Theme.positionColor(p.getPosition())));
        JLabel goals = Theme.label(p.getGoals() + " goals", 13, Font.BOLD, Theme.GREEN);
        row.add(rk, BorderLayout.WEST);
        row.add(mid, BorderLayout.CENTER);
        row.add(goals, BorderLayout.EAST);
        return row;
    }

    private JComponent buildNextMatch() {
        JPanel p = box(new BorderLayout(0, 14));
        List<Match> up = store.upcoming();
        JPanel info = box(null);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        if (up.isEmpty()) {
            JLabel a = Theme.label("No match scheduled", 21, Font.BOLD, Theme.TEXT);
            JLabel b = Theme.label("Open Match Day to add your next fixture.", 13, Font.PLAIN, Theme.MUTED);
            a.setAlignmentX(LEFT_ALIGNMENT);
            b.setAlignmentX(LEFT_ALIGNMENT);
            Theme.Btn go = Theme.button("Open Match Day", Theme.Kind.SECONDARY).compact();
            go.addActionListener(e -> app.navigate("Match Day"));
            go.setAlignmentX(LEFT_ALIGNMENT);
            info.add(a);
            info.add(Box.createVerticalStrut(4));
            info.add(b);
            info.add(Box.createVerticalStrut(12));
            info.add(go);
        } else {
            Match m = up.get(0);
            long days = ChronoUnit.DAYS.between(LocalDate.now(), m.getDate());
            String when = days == 0 ? "Today" : days == 1 ? "Tomorrow" : days < 0 ? Math.abs(days) + " days overdue" : "In " + days + " days";
            JLabel vs = Theme.label("vs " + m.getOpponent(), 22, Font.BOLD, Theme.TEXT);
            JLabel line = Theme.label(m.getDate().format(DAY) + "  ·  " + m.getVenue(), 13, Font.PLAIN, Theme.MUTED);
            JLabel pill = new JLabel(when) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    Theme.aa(g2);
                    g2.setColor(Theme.alpha(Theme.GREEN, 34));
                    g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, getHeight(), getHeight());
                    g2.setColor(Theme.alpha(Theme.GREEN, 150));
                    g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, getHeight(), getHeight());
                    g2.dispose();
                    super.paintComponent(g);
                }
            };
            pill.setFont(Theme.font(Font.BOLD, 12));
            pill.setForeground(Theme.GREEN);
            pill.setBorder(new EmptyBorder(5, 14, 5, 14));
            pill.setAlignmentX(LEFT_ALIGNMENT);
            vs.setAlignmentX(LEFT_ALIGNMENT);
            line.setAlignmentX(LEFT_ALIGNMENT);
            info.add(pill);
            info.add(Box.createVerticalStrut(10));
            info.add(vs);
            info.add(Box.createVerticalStrut(3));
            info.add(line);
            info.add(Box.createVerticalStrut(14));
            Theme.Btn manage = Theme.button("Manage fixtures", Theme.Kind.SECONDARY).compact();
            manage.addActionListener(e -> app.navigate("Match Day"));
            manage.setAlignmentX(LEFT_ALIGNMENT);
            info.add(manage);
        }
        p.add(info, BorderLayout.CENTER);

        // recent form chips
        JPanel form = box(new FlowLayout(FlowLayout.LEFT, 6, 0));
        form.add(Theme.label("Form", 12, Font.BOLD, Theme.MUTED));
        List<Match> res = store.results();
        for (int i = 0; i < Math.min(5, res.size()); i++) form.add(formChip(res.get(i).getResultLetter()));
        if (res.isEmpty()) form.add(Theme.label("no results yet", 12, Font.PLAIN, Theme.MUTED));
        p.add(form, BorderLayout.SOUTH);
        return p;
    }

    static JComponent formChip(String letter) {
        Color c = letter.equals("W") ? Theme.GREEN : letter.equals("D") ? Theme.GOLD : Theme.RED;
        return new JComponent() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                Theme.aa(g2);
                g2.setColor(Theme.alpha(c, 40));
                g2.fillOval(0, 0, getWidth() - 1, getHeight() - 1);
                g2.setColor(Theme.alpha(c, 170));
                g2.drawOval(0, 0, getWidth() - 1, getHeight() - 1);
                g2.setColor(c);
                g2.setFont(Theme.font(Font.BOLD, 12));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(letter, (getWidth() - fm.stringWidth(letter)) / 2, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(28, 28); }
        };
    }
}
