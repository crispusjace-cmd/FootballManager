import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.function.Supplier;

/** Styled pop-up dialogs (forms and confirmations) that match the app theme. */
public final class FormDialog {

    private FormDialog() {}

    /**
     * Shows a form. The validator returns an error message (dialog stays open)
     * or null when everything is fine. Returns true if the user pressed the main button.
     */
    public static boolean show(Component parent, String title, String subtitle, String okText,
                               String[] labels, JComponent[] inputs, Supplier<String> validator) {
        return open(parent, title, subtitle, okText, Theme.Kind.PRIMARY, labels, inputs, validator);
    }

    public static boolean confirm(Component parent, String title, String message, String okText, boolean danger) {
        return open(parent, title, message, okText, danger ? Theme.Kind.DANGER : Theme.Kind.PRIMARY,
                new String[0], new JComponent[0], null);
    }

    private static JPanel fieldCell(String label, JComponent input) {
        JPanel p = new JPanel(new BorderLayout(0, 6));
        p.setOpaque(false);
        p.add(Theme.caption(label), BorderLayout.NORTH);
        p.add(input, BorderLayout.CENTER);
        return p;
    }

    private static boolean open(Component parent, String title, String subtitle, String okText, Theme.Kind kind,
                                String[] labels, JComponent[] inputs, Supplier<String> validator) {
        Window owner = parent == null ? null : SwingUtilities.getWindowAncestor(parent);
        JDialog dialog = new JDialog(owner, Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setUndecorated(true);
        final boolean[] result = {false};

        JPanel root = new JPanel(new BorderLayout(0, 18));
        root.setBackground(Theme.CARD);
        root.setBorder(new CompoundBorder(new LineBorder(Theme.BORDER, 1), new EmptyBorder(26, 28, 22, 28)));

        JPanel head = new JPanel();
        head.setOpaque(false);
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        JLabel t = Theme.label(title, 21, Font.BOLD, Theme.TEXT);
        t.setAlignmentX(Component.LEFT_ALIGNMENT);
        head.add(t);
        if (subtitle != null && !subtitle.isEmpty()) {
            head.add(Box.createVerticalStrut(6));
            JLabel s = new JLabel("<html><body style='width:340px'>" + subtitle + "</body></html>");
            s.setFont(Theme.font(Font.PLAIN, 13));
            s.setForeground(Theme.MUTED);
            s.setAlignmentX(Component.LEFT_ALIGNMENT);
            head.add(s);
        }
        root.add(head, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;
        int row = 0;
        for (int i = 0; i < labels.length; i++) {
            JComponent cell;
            boolean half = labels[i].startsWith("~");
            if (half && i + 1 < labels.length && labels[i + 1].startsWith("~")) {
                // two short fields side by side
                JPanel pair = new JPanel(new GridLayout(1, 2, 12, 0));
                pair.setOpaque(false);
                pair.add(fieldCell(labels[i].substring(1), inputs[i]));
                pair.add(fieldCell(labels[i + 1].substring(1), inputs[i + 1]));
                i++;
                cell = pair;
            } else {
                cell = fieldCell(half ? labels[i].substring(1) : labels[i], inputs[i]);
            }
            c.gridy = row++;
            c.insets = new Insets(row == 1 ? 0 : 14, 0, 0, 0);
            form.add(cell, c);
        }
        JLabel error = Theme.label(" ", 12, Font.PLAIN, Theme.RED);
        c.gridy = row;
        c.insets = new Insets(10, 0, 0, 0);
        form.add(error, c);
        root.add(form, BorderLayout.CENTER);

        Theme.Btn cancel = Theme.button("Cancel", Theme.Kind.SECONDARY);
        Theme.Btn ok = Theme.button(okText, kind);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttons.setOpaque(false);
        buttons.add(cancel);
        buttons.add(ok);
        root.add(buttons, BorderLayout.SOUTH);

        cancel.addActionListener(e -> dialog.dispose());
        ok.addActionListener(e -> {
            String problem = validator == null ? null : validator.get();
            if (problem != null) {
                error.setText(problem);
                dialog.pack();
                return;
            }
            result[0] = true;
            dialog.dispose();
        });
        dialog.getRootPane().registerKeyboardAction(e -> dialog.dispose(),
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);
        dialog.getRootPane().setDefaultButton(null);
        for (JComponent in : inputs) {
            if (in instanceof JTextField) ((JTextField) in).addActionListener(e -> ok.doClick());
        }

        // drag the dialog by its heading
        final Point[] start = {null};
        head.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { start[0] = e.getPoint(); }
        });
        head.addMouseMotionListener(new MouseMotionAdapter() {
            @Override public void mouseDragged(MouseEvent e) {
                Point p = dialog.getLocation();
                dialog.setLocation(p.x + e.getX() - start[0].x, p.y + e.getY() - start[0].y);
            }
        });

        dialog.setContentPane(root);
        dialog.pack();
        dialog.setSize(Math.max(430, dialog.getWidth()), dialog.getHeight());
        dialog.setLocationRelativeTo(owner);
        if (inputs.length > 0) {
            for (JComponent in : inputs) {
                if (in.isEnabled() && in instanceof JTextField) {
                    SwingUtilities.invokeLater(in::requestFocusInWindow);
                    break;
                }
            }
        }
        dialog.setVisible(true);
        return result[0];
    }
}
