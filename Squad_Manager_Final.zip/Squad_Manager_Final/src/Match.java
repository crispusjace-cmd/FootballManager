import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** A fixture (not played yet) or a result (played). */
public class Match {

    private final String opponent;
    private final LocalDate date;
    private final String venue;          // "Home" or "Away"
    private int goalsFor;
    private int goalsAgainst;
    private boolean played;
    private final List<Integer> scorers = new ArrayList<>();   // shirt numbers

    public Match(String opponent, LocalDate date, String venue) {
        this.opponent = opponent;
        this.date = date;
        this.venue = venue;
    }

    public void setResult(int goalsFor, int goalsAgainst, List<Integer> scorers) {
        this.goalsFor = goalsFor;
        this.goalsAgainst = goalsAgainst;
        this.played = true;
        this.scorers.clear();
        this.scorers.addAll(scorers);
    }

    public String getOpponent() { return opponent; }
    public LocalDate getDate() { return date; }
    public String getVenue() { return venue; }
    public int getGoalsFor() { return goalsFor; }
    public int getGoalsAgainst() { return goalsAgainst; }
    public boolean isPlayed() { return played; }
    public List<Integer> getScorers() { return scorers; }

    /** "W", "D" or "L" (or "-" if not played yet). */
    public String getResultLetter() {
        if (!played) return "-";
        if (goalsFor > goalsAgainst) return "W";
        if (goalsFor == goalsAgainst) return "D";
        return "L";
    }
}
