import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.function.Consumer;

/** Full-window login / create-account screen. */
public class LoginPanel extends JPanel {

    private final AuthService auth;
    private final Consumer<String> onSuccess;
    private boolean registerMode;

    private final Theme.Field user = new Theme.Field("", "Username");
    private final Theme.PassField pass = new Theme.PassField("Password");
    private final Theme.PassField confirm = new Theme.PassField("Repeat password");
    private final JPanel confirmRow = new JPanel(new BorderLayout(0, 6));
    private final JLabel title = Theme.label("", 26, Font.BOLD, Theme.TEXT);
    private final JLabel subtitle = new JLabel();
    private final JLabel error = Theme.label(" ", 12.5f, Font.PLAIN, Theme.RED);
    private final Theme.Btn submit = Theme.button("", Theme.Kind.PRIMARY);
    private final Theme.Btn toggle = Theme.button("", Theme.Kind.GHOST);

    public LoginPanel(AuthService auth, Consumer<String> onSuccess) {
        this.auth = auth;
        this.onSuccess = onSuccess;
        this.registerMode = !auth.hasUsers();
        setLayout(new GridBagLayout());

        Theme.Rounded card = new Theme.Rounded(new BorderLayout(0, 20), Theme.CARD, Theme.BORDER, 26);
        card.setBorder(new EmptyBorder(34, 38, 28, 38));
        card.setPreferredSize(new Dimension(440, 520));

        // brand
        JComponent mark = new JComponent() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                Theme.aa(g2);
                g2.setPaint(new GradientPaint(0, 0, new Color(52, 232, 140), 0, getHeight(), new Color(16, 160, 96)));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 18, 18);
                Icons.draw("ball", g2, 11, 11, getWidth() - 22, new Color(4, 28, 18));
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(56, 56); }
        };
        JPanel head = new JPanel();
        head.setOpaque(false);
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        mark.setAlignmentX(LEFT_ALIGNMENT);
        mark.setMaximumSize(new Dimension(56, 56));
        title.setAlignmentX(LEFT_ALIGNMENT);
        subtitle.setFont(Theme.font(Font.PLAIN, 13.5f));
        subtitle.setForeground(Theme.MUTED);
        subtitle.setAlignmentX(LEFT_ALIGNMENT);
        head.add(mark);
        head.add(Box.createVerticalStrut(18));
        head.add(title);
        head.add(Box.createVerticalStrut(6));
        head.add(subtitle);
        card.add(head, BorderLayout.NORTH);

        // form
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.weightx = 1; c.fill = GridBagConstraints.HORIZONTAL;
        c.gridy = 0; form.add(cell("Username", user), c);
        c.gridy = 1; c.insets = new Insets(14, 0, 0, 0); form.add(cell("Password", pass), c);
        confirmRow.setOpaque(false);
        confirmRow.add(Theme.caption("Confirm password"), BorderLayout.NORTH);
        confirmRow.add(confirm, BorderLayout.CENTER);
        c.gridy = 2; form.add(confirmRow, c);
        c.gridy = 3; c.insets = new Insets(10, 0, 0, 0); form.add(error, c);
        card.add(form, BorderLayout.CENTER);

        // buttons
        JPanel bottom = new JPanel(new GridLayout(2, 1, 0, 8));
        bottom.setOpaque(false);
        submit.setPreferredSize(new Dimension(300, 44));
        bottom.add(submit);
        bottom.add(toggle);
        card.add(bottom, BorderLayout.SOUTH);
        add(card);

        submit.addActionListener(e -> submit());
        toggle.addActionListener(e -> { registerMode = !registerMode; error.setText(" "); applyMode(); });
        java.awt.event.ActionListener enter = e -> submit();
        user.addActionListener(enter);
        pass.addActionListener(enter);
        confirm.addActionListener(enter);
        applyMode();
        SwingUtilities.invokeLater(user::requestFocusInWindow);
    }

    private JPanel cell(String label, JComponent input) {
        JPanel p = new JPanel(new BorderLayout(0, 6));
        p.setOpaque(false);
        p.add(Theme.caption(label), BorderLayout.NORTH);
        p.add(input, BorderLayout.CENTER);
        return p;
    }

    private void applyMode() {
        title.setText(registerMode ? "Create your account" : "Welcome back, Coach");
        subtitle.setText(registerMode ? "Set up your coach login to protect your squad." : "Log in to manage your squad.");
        submit.setText(registerMode ? "Create account" : "Log in");
        toggle.setText(registerMode && auth.hasUsers() ? "I already have an account"
                : registerMode ? " " : "Create a new account");
        toggle.setVisible(!(registerMode && !auth.hasUsers()));
        confirmRow.setVisible(registerMode);
        pass.setText("");
        confirm.setText("");
        revalidate();
        repaint();
    }

    private void submit() {
        String u = user.getText().trim();
        String p = new String(pass.getPassword());
        if (registerMode) {
            if (!p.equals(new String(confirm.getPassword()))) { error.setText("Passwords do not match."); return; }
            String problem = auth.register(u, p);
            if (problem != null) { error.setText(problem); return; }
        }
        String name = auth.authenticate(u, p);
        if (name == null) {
            error.setText("Wrong username or password.");
            pass.setText("");
            return;
        }
        onSuccess.accept(name);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setPaint(new GradientPaint(0, 0, Theme.BG_TOP, 0, getHeight(), Theme.BG));
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.setPaint(new RadialGradientPaint(getWidth() * 0.5f, getHeight() * 0.4f, Math.max(getWidth(), getHeight()) * 0.45f,
                new float[]{0f, 1f}, new Color[]{Theme.alpha(Theme.GREEN, 26), Theme.alpha(Theme.GREEN, 0)}));
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.dispose();
    }
}
