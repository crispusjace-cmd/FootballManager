import java.util.ArrayList;
import java.util.List;

/** Pitch positions for each supported formation (x and y are fractions 0..1, attack is at the top). */
public final class Formations {

    public static final String[] NAMES = {"4-4-2", "4-3-3", "3-5-2", "4-2-3-1", "5-3-2"};

    public static final class Slot {
        public final double x, y;
        public final String role;   // GK, DF, MF, FW
        Slot(double x, double y, String role) { this.x = x; this.y = y; this.role = role; }
    }

    private Formations() {}

    public static Slot[] get(String name) {
        List<Slot> s = new ArrayList<>();
        row(s, "GK", 0.90, 0.5);
        switch (name) {
            case "4-4-2":
                row(s, "DF", 0.72, 0.12, 0.37, 0.63, 0.88);
                row(s, "MF", 0.48, 0.12, 0.37, 0.63, 0.88);
                row(s, "FW", 0.22, 0.35, 0.65);
                break;
            case "3-5-2":
                row(s, "DF", 0.73, 0.22, 0.5, 0.78);
                row(s, "MF", 0.48, 0.09, 0.30, 0.5, 0.70, 0.91);
                row(s, "FW", 0.22, 0.35, 0.65);
                break;
            case "4-2-3-1":
                row(s, "DF", 0.72, 0.12, 0.37, 0.63, 0.88);
                row(s, "MF", 0.55, 0.35, 0.65);
                row(s, "MF", 0.38, 0.17, 0.5, 0.83);
                row(s, "FW", 0.17, 0.5);
                break;
            case "5-3-2":
                row(s, "DF", 0.71, 0.08, 0.29, 0.5, 0.71, 0.92);
                row(s, "MF", 0.48, 0.25, 0.5, 0.75);
                row(s, "FW", 0.22, 0.35, 0.65);
                break;
            default: // 4-3-3
                row(s, "DF", 0.72, 0.12, 0.37, 0.63, 0.88);
                row(s, "MF", 0.50, 0.25, 0.5, 0.75);
                row(s, "FW", 0.21, 0.17, 0.5, 0.83);
        }
        return s.toArray(new Slot[0]);
    }

    private static void row(List<Slot> list, String role, double y, double... xs) {
        for (double x : xs) list.add(new Slot(x, y, role));
    }
}
